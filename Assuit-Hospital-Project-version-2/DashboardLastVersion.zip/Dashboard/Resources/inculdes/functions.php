<?php

/**
 * that function to echo page title
 */
function putPageTitle()
{
    //global key word mean that this variable $pageTitle is global mean search about it in global Scope
    global $pageTitle;

    if (isset($pageTitle)) {
        echo $pageTitle;
    } else {
        echo "مستشفيات جامعة اسيوط";
    }
}

/**
 * getLayest()
 * return the lastest $order from table..
 */
function getLayest($selected, $table, $order, $limit = 5)
{

    global $connection;

    $statment3 = $connection->prepare("SELECT $selected FROM $table ORDER BY $order DESC LIMIT $limit");

    $statment3->execute();

    $rows = $statment3->fetchAll();

    return $rows;
}

function getAll($selected, $table, $order)
{

    global $connection;

    $statment3 = $connection->prepare("SELECT $selected FROM $table ORDER BY $order");

    $statment3->execute();

    $rows = $statment3->fetchAll();

    return $rows;
}


function getCount($table)
{
    global $connection;

    $statment3 = $connection->prepare("SELECT COUNT(ID) FROM $table");

    $statment3->execute();

    $rows = $statment3->fetchColumn();

    return $rows;
}

function insertInto($coulmns, $table, $values)
{
    try {
        global $connection;

        $statment3 = $connection->prepare("INSERT INTO $table($coulmns) VALUES ($values) ");

        $statment3->execute();
        echo "insert done <br/>";
        return true;
    } catch (Exception $ex) {
        echo "insert error<br/>";
        return false;
    }
}

function SelectWhereID($table, $id)
{
    global $connection;

    $statment3 = $connection->prepare("SELECT * FROM $table WHERE ID = $id LIMIT 1");

    $statment3->execute();

    $rows = $statment3->fetchAll();

    return $rows;
}
function getLastID($table)
{
    global $connection;

    $statment3 = $connection->prepare("SELECT ID FROM $table ORDER BY ID DESC LIMIT 1");

    $statment3->execute();

    $rows = $statment3->fetchAll();

    return $rows[0]['ID'];
}
function ChickItem($selected , $table , $value ) {
        
    //mean I refer to Global Variable -> $connection
     try{

       global $connection;

       $statment = $connection->prepare("SELECT $selected FROM $table WHERE $selected = ?");

       $statment->execute(array($value));

       return $statment->rowCount();

   }catch(PDOException $e){
       echo $e->getMessage();
   }

}


/* Validation functions */

function StringEmpty($str){
    if (empty ($str)) {  
        return true;  //error
    } else {  
        return false;    
    } 
}
function goodName($name){
    if (!preg_match ('/^[a-zA-Z]*/', $name) ) {  
        return true; //error
    } else {  
        return false;   
    }   
}

function validateEmail($email){
    $pattern = "^[_a-z0-9-]+(\.[_a-z0-9-]+)*@[a-z0-9-]+(\.[a-z0-9-]+)*(\.[a-z]{2,3})$^";  
    if (!preg_match ($pattern, $email) ){  
        return true;//error
    } else {  
        return false;  
    }  
}