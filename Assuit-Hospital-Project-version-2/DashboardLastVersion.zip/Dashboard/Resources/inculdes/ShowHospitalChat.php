<?php
$chat = getAll('id,messages,response', $chatInfo[1], 'id');
?>
<div class="row">
    <div class="col-12" dir="rtl">
        <br />
        <hr />
        <h4 style="display: inline-block;">
            <i class="fa fa-hospital-o"></i>
            <?php echo $chatInfo[0]; ?>
        </h4>

        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <a href="#" style="float: left;margin-top: -5px;" type="button" class="btn btn-info text-white"> أضافة أستفسار
            <i class="fa fa-plus" aria-hidden="true"></i>
        </a>
        <!--Tables-->
        <table class="table table-striped  table-hover" dir="rtl">
            <thead>
                <tr dir="rtl">
                    <th>الاستفسار</th>
                    <th>الجواب</th>
                    <th>التحكم</th>
                </tr>
            </thead>

            <tbody>
                <?php
                foreach ($chat as  $Item) {
                    echo "<tr>";
                    echo "<td>" . $Item['messages'] . "</td>";
                    echo "<td>" . $Item['response'] . "</td>";
                    echo "<td>
                            <a href='#' class='btn btn-success'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-pencil' aria-hidden='true'></i>
                            تعديل</a>
                            <a href='#' class='btn btn-danger confirm'><span class=\"glyphicon glyphicon-remove\"></span>
                            <i class='fa fa-trash-o' aria-hidden='true'></i>حذف</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <br />
        <br />
        <hr />
    </div>
</div>