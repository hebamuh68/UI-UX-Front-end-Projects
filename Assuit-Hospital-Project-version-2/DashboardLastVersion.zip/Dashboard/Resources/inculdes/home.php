<?php
$adminsCount =  getCount('Admin');
$hospitalsCount =  getCount('Hospital');
$clincsCount =  getCount('Clinic');
$articalsCount =  getCount('artical');
$eventsCount =  getCount('events');
$deptsCount =  getCount('Department');
$messagesCount =  getCount('Message');
$homehopitals = getLayest('ID,Name,About', 'Hospital', 'ID', 5);
$homeNews = getLayest('ID,NewsDate,Title', 'News', 'ID', 5);
?>

<div class="row mt-3" id="ShortInfo">
    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-info text-white" style="border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                    <?php echo $hospitalsCount; ?>
                </h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفيات</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-hospital-o" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Hospitals.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>

    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-success text-white" style="border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;"><?php echo $clincsCount; ?></h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">عيادات</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-heartbeat" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Clinic.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>

    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-warning text-white" style="border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;"><?php echo $messagesCount; ?></h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">رسالة</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments-o" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Messages.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>

    <div class="col-lg-3 col-6">
        <!-- small box -->
        <div class="small-box bg-danger text-white" style="border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;"><?php echo $adminsCount; ?></h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مشرف</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-shield" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Admins.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>

    <!--المستشقي القلب-->
    <div class="col-lg-3 col-6" style="margin-top:20px">
        <!-- small box -->
        <div class="small-box text-white" style="background-color: goldenrod;border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                    <?php echo $articalsCount; ?>
                </h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مقالات</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-book" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Articals.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>
    <!-- مستشفي صحة المراة -->
    <div class="col-lg-3 col-6" style="margin-top:20px">
        <!-- small box -->
        <div class="small-box text-white" style="background-color:gray;border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                    <?php echo $eventsCount; ?>
                </h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">حدث مخطط له</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-calendar" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Events.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>
    <!--المستشقي أم القصور-->
    <div class="col-lg-3 col-6" style="margin-top:20px">
        <!-- small box -->
        <div class="small-box bg-info text-white" style="border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                    9
                </h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">غرف دردشة الكترونية</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>Chats.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>
    <!--المسالك-->
    <div class="col-lg-3 col-6" style="margin-top:20px">
        <!-- small box -->
        <div class="small-box bg-success text-white" style="border-radius: 10px;
padding: 5px;">
            <div class="inner">
                <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                    <?php echo $deptsCount; ?>
                </h3>

                <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">قسم</p>
            </div>
            <div class="icon">
                <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-puzzle-piece" aria-hidden="true"></i>
            </div>
            <a href="<?php echo $path; ?>departments.php" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                    aria-hidden="true"></i></a>
        </div>
    </div>

</div>
<hr />
<h2 dir="rtl">أحدث المعلومات في لوحة التحكم</h2>
<hr />
<h4>
    <i class="fa fa-hospital-o"></i>
    معلومات المستشفيات
</h4>
<!--Tables-->
<table class="table table-striped" dir="rtl">
    <thead>
        <tr dir="rtl">
            <th>#</th>
            <th>أسم المستشفي</th>
            <th>
                تحكم
            </th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($homehopitals as $hosp) {
            echo "<tr>";
            echo "<td>" . $hosp['ID'] . "</td>";
            echo "<td>" . $hosp['Name'] . "</td>";
            echo "<td>
                          <a href='Hospitals.php?do=Show&Hospital_ID=" . $hosp['ID'] . "' class='btn btn-info'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-eye' aria-hidden='true'></i>
                            المزيد عن المستشفي</a>
                      </td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>
<br />
<hr />
<h4>
    <i class="fa fa-newspaper-o"></i>
    أحدث الأخبار
</h4>
<!--Tables-->
<table class="table table-striped" dir="rtl">
    <thead>
        <tr dir="rtl">
            <th>تاريخ الخبر</th>
            <th>عنوان الخبر</th>
            <th>
                تحكم
            </th>
        </tr>
    </thead>
    <tbody>
        <?php
        foreach ($homeNews as $hosp) {
            echo "<tr>";
            echo "<td>" . $hosp['NewsDate'] . "</td>";
            echo "<td>" . $hosp['Title'] . "</td>";
            echo "<td>
                          <a href='News.php?do=Show&News_ID=" . $hosp['ID'] . "' class='btn btn-info'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-eye' aria-hidden='true'></i>
                            المزيد عن المستشفي</a>
                      </td>";
            echo "</tr>";
        }
        ?>
    </tbody>
</table>
<br />
<br />
<hr />