<?php
$departmentId = intval($GLOBALS['department_ID']);
$check = ChickItem('ID', 'Department', $departmentId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا القسم غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_Department =  SelectWhereID('Department', $departmentId);
    $HoptialDept =  SelectWhereID('Hospital', intval($the_Department[0]['HospitalID']));
    // echo $the_Department[0]['HospitalID'];
    // print_r($HoptialDept);
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-primary">تفاصيل القسم</h1>
        <h2><span class="text-primary">أسم القسم: </span><?php echo $the_Department[0]['Name']; ?></h2>
        <h2><span class="text-primary">تخصص القسم: </span><?php echo $the_Department[0]['Specialization']; ?></h2>
        <h5><span class="text-primary">عن القسم:</span><?php echo $the_Department[0]['About']; ?></h5>
        <h5><span class="text-primary">القسم خاص بمستشفيى</span><?php echo $HoptialDept[0]['Name']; ?></h5>
        <hr />
        <a href="<?php echo $path; ?>departments.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-puzzle-piece"></i>
            عودة لصفحة الأقسام
        </a>
        &#160;&#160;
        <a href="<?php echo $path; ?>Welcome.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
    </div>
</div>