<?php

$clinicId = intval($GLOBALS['Clinic_ID']);
$check = ChickItem('ID', 'Clinic', $clinicId);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه العيادة غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $res =  SelectWhereID('Clinic', $clinicId);
    $Clinics = getAll('ID,Specialization,About', 'Clinic', 'ID');
}
$departments  = getAll('ID,Name', 'Department', 'ID');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo "<pre dir='ltr'>" . print_r($_POST) . "</pre>";

    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = 'UPDATE  Clinic
            SET Specialization = :Specialization,
                About    = :About,
                Dept_ID  = :Dept_ID
            WHERE ID = :ID';
    // echo "after step 1 ok!";
    $statement = $pdo->prepare($sql);
    //echo "after step 2 ok!";
    $statement->bindParam(':ID', $ID, PDO::PARAM_INT);
    $statement->bindParam(':Specialization', $Specialization);
    $statement->bindParam(':About', $About);
    $statement->bindParam(':Dept_ID', $Dept_ID);
    $ID = $_POST['ID'];
    $Specialization = $_POST['Specialization'];
    $About = $_POST['About'];
    $Dept_ID = $_POST['Dept_ID'];
    //echo "after step 3 ok!";
    if ($statement->execute()) {
        echo "<div class='alert alert-success'>تم التعديل بنجاح</div>";
        $res =  SelectWhereID('Clinic', $GLOBALS['Clinic_ID']);
    } else {
        echo "error in execution of statment";
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">تعديل بيانات العيادة</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=edit&Clinic_ID=' . $clinicId; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $res[0]['ID']; ?>" />

            <div class="form-group">
                <label for="Specialization">تخصص العيادة : </label>
                <input value="<?php echo $res[0]['Specialization'] ? $res[0]['Specialization'] : ""; ?>" type="text"
                    class="form-control" id="Specialization" required placeholder="أدخل تخصص العيادة :"
                    name="Specialization">
            </div>
            <div class="form-group">
                <label for="About">عن العيادة </label>
                <input value="<?php echo $res[0]['About'] ? $res[0]['About'] : ""; ?>" type="text" class="form-control"
                    id="About" required placeholder="ادخل نبذة مختصرة عن العيادة" name="About">
            </div>
            <div class="form-group">
                <label for="Dept_ID">العيادة خاصة بقسم  </label>
                <select id="Dept_ID" name="Dept_ID" class="form-control">
                    <?php
                    foreach ($departments as $h) {
                        if($h['ID'] == intval($res[0]['Dept_ID']))
                           {
                            echo '<option selected value=' . $h['ID'].'>' . $h['Name'] . '</option>';
                           }else{
                            echo '<option value=' . $h['ID'].'>' . $h['Name'] . '</option>';
                           }
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">تعديل العيادة</button>
            &#160;
            <a href="<?php echo $path; ?>Clinic.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لعرض العيادات
            </a>
        </form>
    </div>
</div>