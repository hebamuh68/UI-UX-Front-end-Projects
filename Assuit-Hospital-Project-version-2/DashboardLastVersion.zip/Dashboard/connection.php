<?php

  $hostInfo = 'mysql:host=localhost;dbname=AssuitHospitals';
  $user     = "root";
  $pass     = "";


  try {

    $connection = new PDO($hostInfo, $user , $pass );

    $connection->setAttribute(PDO::ATTR_ERRMODE,PDO::ERRMODE_EXCEPTION);

   // echo "Connection done Successfully...";

  } catch (PDOEXCEPTION $e) {

  	echo "faild in Connection As ".$e->getMessage();

  }