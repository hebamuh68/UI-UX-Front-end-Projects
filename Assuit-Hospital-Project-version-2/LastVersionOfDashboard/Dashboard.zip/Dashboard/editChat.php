<?php

$pageTitle = "لوحة التحكم-غرف الدردشة";
session_start();
include 'pathes.php';
$chats = [
    'mainHospital' => [
        'غرفة دردشة المستشفي الرئيسي',
        'mainchat',
        'mainHospital'
    ],
    'childrenHospital' => [
        'غرفة دردشة مستشفي الأطفال',
        'chatbot',
        'childrenHospital'
    ],
    'brainHospital' => [
        'غرفة دردشة مستشفي الامراض النفسية',
        'brainchat',
        'brainchat'
    ],
    'heartHospital' => [
        'غرفة دردشة مستشفي القلب الجامعي',
        'heartchat',
        'heartHospital'
    ],
    'AlRaghyHospital' => [
        'غرفة دردشة مستشفي الراجحي للكبد',
        'liverchat',
        'AlRaghyHospital'
    ],
    'msalekHospital' => [
        'غرفة دردشة مستشفي المسالك البولية ',
        'msalekchat',
        'msalekHospital'
    ],
    'newassiutHospital' => [
        'غرفة دردشة مستشفي أسيوط الجديدة ',
        'newassiutchat',
        'newassiutHospital'
    ],
    'om2sorhospital' => [
        'غرفة دردشة مستشفي أم القصور',
        'om2sorchat',
        'om2sorhospital'
    ],
    'womanHospital' => [
        'غرفة دردشة مستشفي صحة المراة ',
        'womanchat',
        'womanHospital'
    ],
];
if (isset($_SESSION['User_Name'])) {
    $chat = getAll('ID,Name,About,Vision,Map', 'Hospital', 'ID');
} else {
    header("Location:index.php");
    exit();
}


?>
<!--Start Content-->

<!--Documention content....-->
<div class="container-fluid m-0 p-0" id="Dashboard">
    <div class="row m-0 p-0">
        <div class="col-12 col-md-9 m-0 p-0" id="mainContent">
            <div class="row m-0 p-0 text-right" dir="rtl">
                <div class="col-12 mainContentHeader text-right" dir="rtl">
                    <img src="Resources/images/Assuit.png" class="float-right circle" width="70px" height="70px" />
                    <h1 class="d-inline-block">مستشفيات جامعة أسيوط</h1>
                    <button type="button" style="float: left;margin-top: 2%;" class="btn btn-danger">
                        <a style="text-decoration: none;" class="text-white" href="<?php echo $path; ?>logOut.php">تسجيل
                            خروج</a>
                    </button>
                </div>
                <div class="col-12 mainContentCoontent text-right" dir="rtl">

                    <!-- Content Here-->
                    <?php
                    if ($_SERVER['QUERY_STRING'] == "") {
                        echo '<div class="alert alert-danger">not founded</div>';
                    } else {
                        parse_str($_SERVER['QUERY_STRING'], $QSarr);
                        //print_r($QSarr);
                        if (array_key_exists('HospitalChat', $QSarr)) {
                            switch ($QSarr['HospitalChat']) {
                                case 'mainHospital':
                                    $chatInfo = $chats['mainHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "childrenHospital":
                                    $chatInfo = $chats['childrenHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "brainHospital":
                                    $chatInfo = $chats['brainHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "heartHospital":
                                    $chatInfo = $chats['heartHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "AlRaghyHospital":
                                    $chatInfo = $chats['AlRaghyHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "msalekHospital":
                                    $chatInfo = $chats['msalekHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "newassiutHospital":
                                    $chatInfo = $chats['newassiutHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "om2sorhospital":
                                    $chatInfo = $chats['om2sorhospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                case "womanHospital":
                                    $chatInfo = $chats['womanHospital'];
                                    include $inculdes . 'EditHospitalChat.php';
                                    break;
                                default:
                                    echo '<div class="alert alert-danger">not founded</div>';
                                    break;
                            }
                        } else {
                            echo "<center style='color:red'>Not Found</center>";
                        }
                    }

                    ?>
                    <!-- Content Here-->
                </div>
                <div class="col-12 mainContentFooter text-center" dir="rtl">
                    <p class="lead" style="padding-top:15px;font-family: tajawal;">
                        Designed and created by <a href="#" class="text-primary">Abstract Developers</a>
                    </p>
                </div>
            </div>
        </div>

        <!--Slider Here -->
        <?php
        include $inculdes . 'sidbar.php';
        ?>
    </div>
</div>
<!-- The End of Documention....-->


<!--End Content-->

<!--import footer-->
<?php
include $inculdes . 'footer.php';
?>