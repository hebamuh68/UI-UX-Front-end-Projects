<?php
$servername = 'localhost';
$username = 'root';
$password = '';
$dbname = "AssuitHospitals";
$con = mysqli_connect($servername, $username, $password, "$dbname");
if (!$conn) {
    die('Could not Connect My Sql via sql lite');
}
echo "connection 2 work successfully .";