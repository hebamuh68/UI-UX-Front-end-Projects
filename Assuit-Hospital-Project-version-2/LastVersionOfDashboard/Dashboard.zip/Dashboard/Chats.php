<?php

$pageTitle = "لوحة التحكم-غرف الدردشة";
session_start();
include 'pathes.php';

if (isset($_SESSION['User_Name'])) {
    //
} else {
    header("Location:index.php");
    exit();
}

?>
<!--Start Content-->

<!--Documention content....-->
<div class="container-fluid m-0 p-0" id="Dashboard">
    <div class="row m-0 p-0">
        <div class="col-12 col-md-9 m-0 p-0" id="mainContent">
            <div class="row m-0 p-0 text-right" dir="rtl">
                <div class="col-12 mainContentHeader text-right" dir="rtl">
                    <img src="Resources/images/Assuit.png" class="float-right circle" width="70px" height="70px" />
                    <h1 class="d-inline-block">مستشفيات جامعة أسيوط</h1>
                    <button type="button" style="float: left;margin-top: 2%;" class="btn btn-danger">
                        <a style="text-decoration: none;" class="text-white" href="<?php echo $path; ?>logOut.php">تسجيل
                            خروج</a>
                    </button>
                </div>
                <div class="col-12 mainContentCoontent text-right" dir="rtl">

                    <!-- Content Here-->
                    <div class="row p-0" style="margin:0px;margin-top: 40px;width:100%">
                        <h4 class="font-weight-bold" style="display: inline-block;width: 80%;">
                            <i class="fa fa-comments"></i>
                            عرض غرف الدردشة
                        </h4>
                        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;"
                            type="button" class="text-white btn btn-info">
                            <i class="fa fa-home"></i>
                            عودة لصفحة الرئيسية
                        </a>
                    </div>
                    <div class="row mt-3" id="ShortInfo">
                        <!--المستشقي الرئيسي-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box bg-info text-white" style="border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">المستشفي الرئيسي</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=mainHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--المستشقي الاطفال-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box text-white" style="background-color: #368412;border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي الأطفال</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=childrenHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--المستشقي الامراض النفسية-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box bg-danger text-white" style="border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي الامراض النفسية</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=brainHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--المستشقي الراجحي-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box text-white" style="background-color: gray;border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي الراجحي للكبد</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=AlRaghyHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--المستشقي القلب-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box text-white" style="background-color: goldenrod;border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي القلب</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=heartHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!-- مستشفي صحة المراة -->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box text-white" style="background-color:gray;border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي صحة المراة</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=womanHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--المستشقي أم القصور-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box bg-info text-white" style="border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي أم القصور</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=om2sorhospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--المسالك-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box bg-success text-white" style="border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي المسالك البولية</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=msalekHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>
                        <!--new assuit-->
                        <div class="col-lg-3 col-6" style="margin-top:20px">
                            <!-- small box -->
                            <div class="small-box bg-danger text-white" style="border-radius: 10px;
padding: 5px;">
                                <div class="inner">
                                    <h3 style="font-size: 30px;
font-weight: bold;
margin: 10px;
padding: 5px;
text-shadow: 2px 2px 2px lightslategray;">
                                        دردشة
                                    </h3>

                                    <p style="font-weight: bold;
text-shadow: 2px 2px 2px lightslategray;">مستشفي أسيوط الجديدة</p>
                                </div>
                                <div class="icon">
                                    <i style="position: absolute;
top: 30px;
left: 30px;
font-size: 32px;
font-weight: 100;" class="fa fa-comments" aria-hidden="true"></i>
                                </div>
                                <a href="<?php echo $path; ?>HospitalChat.php?HospitalChat=newassiutHospital" style="color: #fff;
font-weight: 400;" class="small-box-footer">المزيد من المعلومات<i class="fa fa-hand-o-right"
                                        aria-hidden="true"></i></a>
                            </div>
                        </div>

                    </div>

                    <!-- Content Here-->
                </div>
                <div class="col-12 mainContentFooter text-center" dir="rtl">
                    <p class="lead" style="padding-top:15px;font-family: tajawal;">
                        Designed and created by <a href="#" class="text-primary">Abstract Developers</a>
                    </p>
                </div>
            </div>
        </div>

        <!--Slider Here -->
        <?php
        include $inculdes . 'sidbar.php';
        ?>
    </div>
</div>
<!-- The End of Documention....-->


<!--End Content-->

<!--import footer-->
<?php
include $inculdes . 'footer.php';
?>