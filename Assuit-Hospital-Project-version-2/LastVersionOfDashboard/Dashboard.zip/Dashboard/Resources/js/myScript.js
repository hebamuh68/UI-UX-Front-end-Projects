/*
 * Prepare my code
*/
'use strict';
var SidebarHidden = true;
/* Go to Top of Page */
window.onscroll = () => {
    let topPage = document.getElementById('top-page-arrow');
    window.scrollY > 500 ? (topPage.style.display = 'block')
        : (topPage.style.display = 'none');

}
function goToTop(){
   window.scroll({
    top: 0, 
    left: 0, 
    behavior: 'smooth' 
   });
}

var arrow_left = false;
function toggleOptions(id,DDLid){
    let angleArrowSidebar = document.getElementById(id);
    let DDL = document.getElementById(DDLid);
    if(arrow_left)
    {
        angleArrowSidebar.setAttribute('class','fa fa-angle-right');
        arrow_left = false;
        DDL.setAttribute('style','display:none');
    }
    else
    {
        angleArrowSidebar.setAttribute('class','fa fa-angle-down');
        arrow_left = true;
        DDL.setAttribute('style','display:block');
    }
}


function SelectIncude(pageName){
    
}