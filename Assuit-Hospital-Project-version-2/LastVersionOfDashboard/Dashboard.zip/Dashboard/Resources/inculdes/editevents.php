<?php

$event_ID = intval($GLOBALS['event_ID']);
$check = ChickItem('id', 'events', $event_ID);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه الحدث غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $res =  SelectWhereID('events', $event_ID);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo "<pre dir='ltr'>" . print_r($_POST) . "</pre>";

    $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $Stat = $conn->prepare("UPDATE  events
                    SET loc = :loc,
                    title    = :title,
                    `date`  = :EventDate
                    WHERE id = $event_ID");
    //$Stat->bindParam(':id', $event_ID);
    $Stat->bindParam(':EventDate', $EventDate);
    $Stat->bindParam(':title', $title);
    $Stat->bindParam(':loc', $loc);
    $id =  $event_ID;
    $EventDate = $_POST['EventDate'];
    $title = $_POST['title'];
    $loc = $_POST['loc'];
    if ($Stat->execute()) {
        echo "<div class='alert alert-success'>تم التعديل بنجاح</div>";
        $res =  SelectWhereID('events', $GLOBALS['event_ID']);
    } else {
        echo "error in execution of statment";
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">تعديل علي حدث </h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=edit&event_ID=' .  $event_ID; ?>" method="POST">
            <input type="hidden" name="id" value="<?php echo $event_ID; ?>" />
            <div class="form-group">
                <label for="EventDate">تاريخ الحدث </label>
                <input type="text" class="form-control" id="EventDate" required placeholder="أدخل التاريخ مثل:22-4-2020"
                    name="EventDate" value="<?php echo $res[0]['date']; ?>">
            </div>
            <div class="form-group">
                <label for="title">عنوان الحدث </label>
                <input type="text" value="<?php echo $res[0]['title']; ?>" class="form-control" id="title" required
                    placeholder="عنوان الحدث" name="title">
            </div>
            <div class="form-group">
                <label for="loc">موقع الحدث </label>
                <textarea type="text" class="form-control" id="loc" placeholder="موقع الحدث"
                    name="loc"><?php echo $res[0]['loc']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">تعديل الحدث</button>
            &#160;
            <a href="<?php echo $path; ?>Events.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة الاحداث
            </a>
        </form>
    </div>
</div>