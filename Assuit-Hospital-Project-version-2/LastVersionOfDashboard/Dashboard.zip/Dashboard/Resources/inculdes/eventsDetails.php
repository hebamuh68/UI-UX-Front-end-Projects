<?php
$eventID = intval($GLOBALS['event_ID']);
$check = ChickItem('id', 'events', $eventID);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا الحدث غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_event =  SelectWhereID('events', $eventID);
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-primary">تفاصيل لحدث</h1>
        <h2><span class="text-primary">العنوان: </span><?php echo $the_event[0]['title']; ?></h2>
        <h2><span class="text-primary">التاريخ: </span><?php echo $the_event[0]['date']; ?></h2>
        <h5><span class="text-primary">المكان:</span><?php echo $the_event[0]['loc']; ?></h5>
        <hr />
        <a href="<?php echo $path; ?>Events.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-calendar"></i>
            عودة لصفحة الأحداث القادمة
        </a>
        &#160;&#160;
        <a href="<?php echo $path; ?>Welcome.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
    </div>
</div>