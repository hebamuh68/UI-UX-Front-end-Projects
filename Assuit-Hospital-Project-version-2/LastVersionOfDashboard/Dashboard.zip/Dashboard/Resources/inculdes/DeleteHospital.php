<?php
$hospitalId = intval($GLOBALS['Hospital_ID']);
$check = ChickItem('ID', 'Hospital', $hospitalId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذة المستشفي غير موجودة لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $hospital =  SelectWhereID('Hospital', $hospitalId);
}
// Report all PHP errors
// error_reporting(E_ALL);
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // construct the delete statement
    $sql3 = "DELETE FROM Hospital 
            WHERE ID = :HospitalID";
    $HospitalID = $_POST['ID'];
    // prepare the statement for execution
    $statement3 = $pdo->prepare($sql3);
    $statement3->bindParam(':HospitalID', $HospitalID, PDO::PARAM_INT);

    // execute the statement
    if ($statement3->execute()) {
        echo '<div class="alert alert-danger">';
        echo '<p class="lead">عملية الحذف تمت بنجاح سيتم توجيهك الى صفحة المستشفيات الأن</p>';
        echo '</div>';
        header("refresh:1; url=Hospitals.php");
    }
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-danger text-center">حذف مستشفي</h1>
        <h2><span class="text-primary">أسم المستشفي : </span><?php echo $hospital[0]['Name']; ?></h2>
        <h5><span class="text-primary">عن الميتشفي :</span></h5>
        <p class="lead"><?php echo $hospital[0]['About']; ?></p>
        <h5><span class="text-primary">روية الميتشفي :</span></h5>
        <p class="lead"><?php echo $hospital[0]['Vision']; ?></p>
        <hr />
        <a href="<?php echo $path; ?>Hospitals.php" type="button" class="text-white btn btn-success">
            <i class="fa fa-newspaper-o"></i>
            عودة لصفحة المستشفيات
        </a>
        &#160;&#160;
        <form class="d-inline" action="<?php echo $_SERVER['PHP_SELF'] . '?do=Delete&Hospital_ID=' . $hospitalId; ?>"
            method="POST">
            <input type="hidden" name="ID" value="<?php echo $hospital[0]['ID']; ?>" />
            <button type="submit" class="text-white btn btn-danger">
                <i class='fa fa-trash-o' aria-hidden='true'></i>
                حذف المستشفي
            </button>
        </form>
    </div>
</div>