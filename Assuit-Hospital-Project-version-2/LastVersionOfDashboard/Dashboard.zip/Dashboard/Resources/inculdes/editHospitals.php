<?php

$hospitalId = intval($GLOBALS['Hospital_ID']);
$check = ChickItem('ID', 'Hospital', $hospitalId);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه المستشفي غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $res =  SelectWhereID('Hospital', $hospitalId);
    $hospitals = getAll('`Name`,About,Vision,Map', 'Hospital', 'ID');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo "<pre dir='ltr'>" . print_r($_POST) . "</pre>";

    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = 'UPDATE  Hospital
            SET `Name` = :Hospital_Name,
                About    = :About ,
                Vision  = :Vision,
                Map = :Map
            WHERE ID = :ID';
    // echo "after step 1 ok!";
    $statement = $pdo->prepare($sql);
    //echo "after step 2 ok!";
    $statement->bindParam(':ID', $ID, PDO::PARAM_INT);
    $statement->bindParam(':Hospital_Name', $Hospital_Name);
    $statement->bindParam(':About', $About);
    $statement->bindParam(':Vision', $Vision);
    $statement->bindParam(':Map', $Map);
    $ID = $_POST['ID'];
    $Hospital_Name = $_POST['Hospital_Name'];
    $About = $_POST['About'];
    $Vision = $_POST['Vision'];
    $Map = $_POST['Map'];
    //echo "after step 3 ok!";
    if ($statement->execute()) {
        echo "<div class='alert alert-success'>تم التعديل بنجاح</div>";
        $res =  SelectWhereID('Hospital', $GLOBALS['Hospital_ID']);
    } else {
        echo "error in execution of statment";
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">تعديل بيانات مستشفي</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=edit&Hospital_ID=' . $hospitalId; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $res[0]['ID']; ?>" />

            <div class="form-group">
                <label for="Hospital_Name">اسم المستشفى </label>
                <input value="<?php echo $res[0]['Name'] ? $res[0]['Name'] : ""; ?>" type="text" class="form-control"
                    id="Hospital_Name" required placeholder="أدخل اسم المستشفى" name="Hospital_Name">
            </div>
            <div class="form-group">
                <label for="About">عن المستشفى </label>
                <input value="<?php echo $res[0]['About'] ? $res[0]['About'] : ""; ?>" type="text" class="form-control"
                    id="About" required placeholder="ادخل نبذة مختصرة عن المستشفى" name="About">
            </div>
            <div class="form-group">
                <label for="Vision">رؤية المستشفى </label>
                <input value="<?php echo $res[0]['Vision'] ? $res[0]['Vision'] : ""; ?>" type="text"
                    class="form-control" id="Vision" required placeholder="رؤية المستشفى" name="Vision">
            </div>
            <div class="form-group">
                <label for="Map">خريطة المستشفى </label>
                <input value="<?php echo $res[0]['Map'] ? $res[0]['Map'] : ""; ?>" type="text" class="form-control"
                    id="Map" required placeholder="خريطة المستشفى" name="Map">
            </div>
            <button type="submit" class="btn btn-primary">تعديل الخبر</button>
            &#160;
            <a href="<?php echo $path; ?>Hospitals.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لعرض المستشفيات
            </a>
        </form>
    </div>
</div>