<?php
$lastEventsID = getLastID('events') + 1;
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (StringEmpty($_POST['EventDate']) || StringEmpty($_POST['title']) || StringEmpty($_POST['loc'])) {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    } else {
        $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //global $connection;
        $Stat = $conn->prepare("INSERT INTO events(id,`date`,title,loc) 
        VALUES (:id,:EventDate,:title,:loc)");
        $Stat->bindParam(':id', $lastEventsID);
        $Stat->bindParam(':EventDate', $EventDate);
        $Stat->bindParam(':title', $title);
        $Stat->bindParam(':loc', $loc);
        $id =  $lastEventsID;
        $EventDate = $_POST['EventDate'];
        $title = $_POST['title'];
        $loc = $_POST['loc'];
        $Stat->execute();
        echo '<div class="alert alert-success">تمت أضافة الحدث بنجاح</div>';
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">أضافة حدث قادم جديد</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST">
            <input type="hidden" name="id" value="<?php echo $lastEventsID + 1; ?>" />
            <div class="form-group">
                <label for="EventDate">تاريخ الحدث </label>
                <input type="text" class="form-control" id="EventDate" required placeholder="أدخل التاريخ مثل:22-4-2020"
                    name="EventDate">
            </div>
            <div class="form-group">
                <label for="title">عنوان الحدث </label>
                <input type="text" class="form-control" id="title" required placeholder="عنوان الحدث" name="title">
            </div>
            <div class="form-group">
                <label for="loc">موقع الحدث </label>
                <textarea type="text" class="form-control" id="loc" placeholder="موقع الحدث" name="loc"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">أضافة الحدث</button>
            &#160;
            <a href="<?php echo $path; ?>Events.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة الاحداث
            </a>
        </form>
    </div>
</div>