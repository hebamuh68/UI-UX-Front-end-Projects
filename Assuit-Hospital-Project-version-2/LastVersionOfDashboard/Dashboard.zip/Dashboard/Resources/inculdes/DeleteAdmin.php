<?php
$adminId = intval($GLOBALS['Admin_Id']);
$check = ChickItem('ID', 'Admin', $adminId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا المشرف غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_Admin =  SelectWhereID('Admin', $adminId);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $adminId = $_POST['adminId'];
    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // construct the delete statement
    $sql = 'DELETE FROM `Admin`
            WHERE ID = :adminId';

    // prepare the statement for execution
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':adminId', $adminId, PDO::PARAM_INT);

    // execute the statement
    if ($statement->execute()) {
        echo '<div class="alert alert-danger">';
        echo '<p class="lead">عملية الحذف تمت بنجاح سيتم توجيهك الى صفحة الأقسام الأن</p>';
        echo '</div>';
        header("refresh:0; url=Admins.php");
    }
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-danger"> حذف المشرف</h1>
        <h2><span class="text-primary">أسم المشرف: </span><?php echo $the_Admin[0]['Name']; ?></h2>
        <h2><span class="text-primary"> درجة المشرف: </span>
            <?php
            if ($the_Admin[0]['SuperAdmin'] == 1)
                echo "مشرف رئيسي";
            else
                echo "مشرف عادي";
            ?>
        </h2>
        <h5><span class="text-primary">صورة:</span><br /><?php echo $the_Admin[0]['Img']; ?></h5>
        <hr />
        <a href="<?php echo $path; ?>Admins.php" type="button" class="text-white btn btn-success">
            <i class="fa fa-users"></i>
            عودة لصفحة المشرفين
        </a>
        &#160;&#160;
        <form class="d-inline" action="<?php echo $_SERVER['PHP_SELF'] . '?do=Delete&Admin_Id=' . $adminId; ?>"
            method="POST">
            <input type="hidden" name="adminId" value="<?php echo $adminId; ?>" />
            <button type="submit" class="text-white btn btn-danger">
                <i class='fa fa-trash-o' aria-hidden='true'></i>
                حذف المشرف
            </button>
        </form>
    </div>
</div>