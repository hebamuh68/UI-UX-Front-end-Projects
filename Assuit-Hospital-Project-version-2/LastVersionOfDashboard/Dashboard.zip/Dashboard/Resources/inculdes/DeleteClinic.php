<?php

$clinicId = intval($GLOBALS['Clinic_ID']);
$check = ChickItem('ID', 'Clinic', $clinicId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه العيادة غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    //header("refresh:1; url=Welcome.php");
} else {
    $res =  SelectWhereID('Clinic', $clinicId);
    $Dept =  SelectWhereID('Department', $res[0]['Dept_ID']);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $clinicId = $_POST['clinicId'];
    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // construct the delete statement
    $sql = 'DELETE FROM Clinic
            WHERE ID = :clinicId';

    // prepare the statement for execution
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':clinicId', $clinicId, PDO::PARAM_INT);

    // execute the statement
    if ($statement->execute()) {
        echo '<div class="alert alert-danger">';
        echo '<p class="lead">عملية الحذف تمت بنجاح سيتم توجيهك الى صفحة العيادات الأن</p>';
        echo '</div>';
        header("refresh:0; url=Clinic.php");
    }
}

?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12 text-primary"> بيانات العيادة</h2>
    <div class="col-12">
        <h4><span class="text-primary">تخصص العيادة : </span>
            <?php echo $res[0]['Specialization'] ? $res[0]['Specialization'] : ""; ?>
        </h4>
        <h4><span class="text-primary">عن العيادة :</span>
            <?php echo $res[0]['About'] ? $res[0]['About'] : ""; ?>
        </h4>
        <h4><span class="text-primary">العيادة خاصة بقسم :</span>
            <?php echo $Dept[0]['Name'] ? $Dept[0]['Name'] : ""; ?>
        </h4>
        <a href="<?php echo $path; ?>Clinic.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-newspaper-o"></i>
            عودة لعرض العيادات
        </a>
        &#160;&#160;
        <form class="d-inline" action="<?php echo $_SERVER['PHP_SELF'] . '?do=Delete&Clinic_ID=' . $clinicId; ?>"
            method="POST">
            <input type="hidden" name="clinicId" value="<?php echo $clinicId; ?>" />
            <button type="submit" class="text-white btn btn-danger">
                <i class='fa fa-trash-o' aria-hidden='true'></i>
                حذف العيادة
            </button>
        </form>
    </div>
</div>