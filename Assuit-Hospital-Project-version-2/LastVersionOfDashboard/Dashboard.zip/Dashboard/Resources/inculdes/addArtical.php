<?php
$lastArticalId = getLastID('artical') + 1;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (
        StringEmpty($_POST['title'])
        || StringEmpty($_POST['keywords'])
        || StringEmpty($_POST['about_re'])
        || StringEmpty($_POST['doctor_name'])
        || StringEmpty($_POST['email'])
        || StringEmpty($_POST['phone'])
    ) {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    } else {
        $hostc = 'localhost';
        $userc = 'root';
        $passc = '';
        $dbc = 'AssuitHospitals';
        $conn = mysqli_connect($hostc, $userc, $passc, $dbc);
        $ssql = 'SET CHARACTER SET utf8';
        mysqli_query($conn, $ssql);
        $insert = "";
        if (isset($_POST['title'])) {
            $title = $_POST['title'];
            $keywords = $_POST['keywords'];
            $date = $_POST['date'];
            $about_re = $_POST['about_re'];
            $doctor_name = $_POST['doctor_name'];
            $phone = $_POST['phone'];
            $email = $_POST['email'];

            if (isset($_POST['submit'])) {

                $file = $_FILES['file'];

                $fileName = $_FILES['file']['name'];

                $fileTmpName = $_FILES['file']['tmp_name'];

                $fileExt = explode('.', $fileName);
                $fileActualExt = strtolower(end($fileExt));

                $allowedf = array('pdf');


                $img = $_FILES['img'];

                $imgName = $_FILES['img']['name'];

                $imgTmpName = $_FILES['img']['tmp_name'];

                $imgExt = explode('.', $imgName);
                $imgActualExt = strtolower(end($imgExt));

                $allowedi = array('jpg', 'jpeg', 'png');

                if (in_array($imgActualExt, $allowedi)) {

                    $imgDestination = '/opt/lampp/htdocs/myPhpWork/Site/Uploads/' . $imgName;
                    move_uploaded_file($imgTmpName, $imgDestination);
                    $image = 'Uploads/' . $imgName;
                    if (in_array($fileActualExt, $allowedf)) {
                        $fileDestination = '/opt/lampp/htdocs/myPhpWork/Site/Uploads/' . $fileName;
                        move_uploaded_file($fileTmpName, $fileDestination);
                        $folder = 'Uploads/' . $fileName;
                        $insert = "insert into artical (title, keywords, about_re , file , doctor_name , phone , img , date, email) values ('$title', '$keywords', '$about_re','$folder','$doctor_name','$phone','$image','$date','$email')";
                    } else {
                        $insert = "insert into artical (title, keywords, about_re  , doctor_name , phone , img , date , email) values ('$title', '$keywords', '$about_re','$doctor_name','$phone','$image','$date','$email')";
                    }
                } else if (in_array($fileActualExt, $allowedf)) {
                    $fileDestination = '/opt/lampp/htdocs/myPhpWork/Site/Uploads/' . $fileName;
                    move_uploaded_file($fileTmpName, $fileDestination);
                    $folder = 'Uploads/' . $fileName;
                    $insert = "insert into artical (title, keywords, about_re , file , doctor_name , phone  , date , email) values ('$title', '$keywords', '$about_re','$folder','$doctor_name','$phone','$date','$email')";
                }
            } else {
                $insert = "insert into artical (title, keywords, about_re , doctor_name , phone  , date , email) values ('$title', '$keywords', '$about_re','$doctor_name','$phone','$date','$email')";
            }

            if ($insert != "") {
                if ($conn->query($insert) === TRUE) {      #insert data
                    echo '<div class="alert alert-success">تمت أضافة المقال بنجاح</div>';
                } else {
                    echo '<div class="alert alert-success">لم تتم الاضافة</div>';
                }
            }
        }
        // if (isset($_GET['id'])) {

        //     $id = $_GET['id'];
        //     $delete = "delete from artical where id='$id'";
        //     if ($conn->query($delete) === TRUE) {      #insert data
        //         echo "deleted successfully";
        //     } else {
        //         echo "Error: " . $delete . "<br>" . $conn->error;
        //     }

        //     header("location: articals.php");
        // }


    }
}
?>
<div class="row mt-4" dir="rtl">
    <h2 class="col-12">إضافة مقال جديد</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST" enctype="multipart/form-data">
            <h5>1 - معلومات عن المقال :</h5>
            <div class="item">
                <p>عنوان المقال<span class="required">*</span></p>
                <input type="text" class="form-control" name="title" required />
            </div>
            <div class="item">
                <p>العناوين الرئيسيه<span class="required">*</span></p>
                <input class="form-control" type="text" name="keywords" />
            </div>
            <div class="item">
                <p>عن المقال ؟ <span class="required">*</span></p>
                <input class="form-control" type="text" name="about_re" required />
            </div>
            <div class="item">
                <p>المقال .pdf<span class="required">*</span></p>
                <input class="form-control" type="file" name="file" required />
            </div>
            <div class="item">
                <p>تاريخ النشر</p>
                <input class="form-control" type="date" name="date" />
                <i class="fas fa-calendar-alt"></i>
            </div>
            <h5>2 - معلومات عن الطبيب الناشر :</h5>
            <div class="item">
                <p>الاسم <span class="required">*</span></p>
                <input class="form-control" type="text" name="doctor_name" required placeholder="Dr/" />
            </div>
            <div class="item">
                <p>البريد الإلكترونى<span class="required">*</span></p>
                <input class="form-control" type="text" name="email" placeholder="@" required />
            </div>
            <div class="item">
                <p>رقم الهاتف<span class="required">*</span></p>
                <input class="form-control" type="text" name="phone" required />
            </div>
            <div class="item">
                <p>صور عن المقال<span class="required">*</span></p>
                <input class="form-control" type="file" name="img" required />
            </div>
            <div class="btn-block" style="margin-top: 20px;">
                <button type="submit" class="btn btn-primary">إضافة المقال</button>
                &#160;
                <a href="<?php echo $path; ?>Articals.php" type="button" class="text-white btn btn-primary">
                    <i class="fa fa-newspaper-o"></i>
                    عودة لصفحة المقالات
                </a>
            </div>


        </form>
    </div>
</div>