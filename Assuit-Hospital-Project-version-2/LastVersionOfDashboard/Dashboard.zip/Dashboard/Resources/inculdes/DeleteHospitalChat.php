<?php
$table = $chatInfo[1];
parse_str($_SERVER['QUERY_STRING'], $QSarr);
if (array_key_exists('ChatID', $QSarr)) {
    $ChatID =  $QSarr['ChatID'];
}
$check = ChickItem('id', $table, $ChatID);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه الدردشة غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    if ($_SERVER['REQUEST_METHOD'] == 'POST') {

        //Error Here
        $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //global $connection;
        $Stat = $conn->prepare("DELETE FROM  $table
    WHERE id = $ChatID");

        $Stat->execute();
        header("refresh:0; url=HospitalChat.php?HospitalChat=" . $chatInfo[2]);
        // echo '<div class="alert alert-success m-0 p-0 text-center font-weight-bold">تم التعديل بنجاح</div>';
    }
    $res =  SelectWhereID($table, $ChatID);
}
?>
<div class="row">
    <div class="col-12" dir="rtl">
        <br />
        <hr />
        <h4 style="display: inline-block;" class="text-danger">
            <i class="fa fa-hospital-o"></i>
            حذف رسالة خاصة ب
            <br />
            <?php echo $chatInfo[0]; ?>
        </h4>

        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <form action="<?php echo $path . 'deleteChat.php?ChatID=' . $res[0]['id'] . '&HospitalChat=' . $chatInfo[2]; ?>"
            method="POST" style="padding-right: 60px;margin-bottom:70px">
            <div class="form-group text-right">
                <textarea class="form-control" placeholder="الأستفسار...." name="messages"
                    rows="4"><?php echo $res[0]['messages']; ?></textarea>
            </div>
            <div class="form-group text-right">
                <textarea class="form-control" placeholder="الرد......" name="response"
                    rows="4"><?php echo $res[0]['response']; ?></textarea>
            </div>
            <button type="submit" class="btn btn-danger">حذف</button>
        </form>

        <br />
        <br />
        <hr />
    </div>
</div>