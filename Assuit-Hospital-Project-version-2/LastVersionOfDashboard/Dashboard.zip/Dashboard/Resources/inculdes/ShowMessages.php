<div class="row">
    <div class="col-12">
        <br />
        <hr />
        <h4 style="display: inline-block;">
            <i class="fa fa-hospital-o"></i>
            عرض الرسائل الواردة
        </h4>
        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <!--Tables-->
        <table class="table table-striped  table-hover" dir="rtl">
            <thead>
                <tr dir="rtl">
                    <th>الراسل</th>
                    <th>الرسالة</th>
                </tr>
            </thead>

            <tbody>
                <?php
                foreach ($messages as  $Item) {
                    echo "<tr>";
                    echo "<td> <a href=mailto:" . $Item['Email'] . ">" . $Item['Email'] . "</td>";
                    echo "<td>" . $Item['Content'] . "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <br />
        <br />
        <hr />
    </div>
</div>