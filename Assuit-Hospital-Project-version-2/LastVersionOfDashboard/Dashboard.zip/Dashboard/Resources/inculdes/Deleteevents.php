<?php

$eventId = intval($GLOBALS['event_ID']);
$check = ChickItem('id', 'events', $eventId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا الحدث غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_Event =  SelectWhereID('events', $eventId);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $eventId = $_POST['eventId'];
    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // construct the delete statement
    $sql = 'DELETE FROM events
            WHERE ID = :eventId';

    // prepare the statement for execution
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':eventId', $eventId, PDO::PARAM_INT);

    // execute the statement
    if ($statement->execute()) {
        echo '<div class="alert alert-danger">';
        echo '<p class="lead">عملية الحذف تمت بنجاح سيتم توجيهك الى صفحة الاحداث الأن</p>';
        echo '</div>';
        header("refresh:0; url=Events.php");
    }
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-danger text-center"></h1>حذف حدث</h1>
        <h2><span class="text-primary">عنوان الحدث: </span><?php echo  $the_Event[0]['title']; ?></h2>
        <hr />
        <a href="<?php echo $path; ?>Events.php" type="button" class="text-white btn btn-success">
            <i class="fa fa-newspaper-o"></i>
            عودة لصفحة الأحداث
        </a>
        &#160;&#160;
        <form class="d-inline" action="<?php echo $_SERVER['PHP_SELF'] . '?do=Delete&event_ID=' .  $eventId; ?>"
            method="POST">
            <input type="hidden" name="eventId" value="<?php echo  $eventId; ?>" />
            <button type="submit" class="text-white btn btn-danger">
                <i class='fa fa-trash-o' aria-hidden='true'></i>
                حذف الحدث
            </button>
        </form>
    </div>
</div>