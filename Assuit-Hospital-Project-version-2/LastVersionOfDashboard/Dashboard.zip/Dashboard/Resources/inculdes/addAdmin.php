<?php
$lastAdminId = getLastID('Admin') + 1;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if (StringEmpty($_POST['Admin_Name']) || StringEmpty($_POST['pass']) || StringEmpty($_POST['Email'])) {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    } else {
        //Error Here
        $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //global $connection;
        $Stat = $conn->prepare("INSERT INTO `Admin` (ID,`Name`,Email,`Password`,SuperAdmin) 
    VALUES (:ID,:Admin_Name,:Email,:pass,:isSuperAdmin)");
        $Stat->bindParam(':ID', $lastAdminId);
        $Stat->bindParam(':Admin_Name', $Admin_Name);
        $Stat->bindParam(':Email', $Email);
        $Stat->bindParam(':pass', $pass);
        $Stat->bindParam(':isSuperAdmin', $isSuperAdmin);
        $ID = $lastAdminId;
        $Admin_Name = $_POST['Admin_Name'];
        $Email = $_POST['Email'];
        $pass = md5($_POST['pass']);
        $isSuperAdmin = intval($_POST['isSuperAdmin']);
        //encrpt password.
        $Stat->execute();
        echo '<div class="alert alert-success">تمت أضافة المشرف بنجاح</div>';
    }
}
?>
<div class="row mt-4" dir="rtl">
    <h2 class="col-12">إضافة مشرف جديد</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $lastAdminId; ?>" />
            <div class="form-group">
                <label for="Hospital_Name">اسم المشرف </label>
                <input type="text" class="form-control" id="Admin_Name" required placeholder="أدخل اسم المشرف"
                    name="Admin_Name">
            </div>
            <div class="form-group">
                <label for="Email">الأيميل </label>
                <input type="email" class="form-control" id="Email" required placeholder="أدخل ايميل المشرف"
                    name="Email">
            </div>
            <div class="form-group">
                <label for="pass">كلمة السر: </label>
                <input type="password" minlength="6" class="form-control" id="pass" required
                    placeholder="أدخل كلمة المرور" name="pass">
            </div>
            <div class="form-group">
                <label for="isSuperAdmin"> نوع المشرف </label>
                <select id="isSuperAdmin" name="isSuperAdmin" class="form-control">
                    <option value="0">مشرف عادي</option>
                    <option value="1">مشرف رئيسي</option>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">إضافة مشرف</button>
            &#160;
            <a href="<?php echo $path; ?>Admins.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة المشرفين
            </a>
        </form>
    </div>
</div>