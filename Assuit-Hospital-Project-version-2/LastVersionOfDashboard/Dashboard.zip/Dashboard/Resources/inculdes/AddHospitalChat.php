<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    //Error Here
    $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //global $connection;
    $table = $chatInfo[1];
    $Stat = $conn->prepare("INSERT INTO $table(messages,response) 
    VALUES (:messages,:response)");
    //$Stat->bindParam(':id', $ID);
    $Stat->bindParam(':messages', $messages);
    $Stat->bindParam(':response', $response);
    // echo "<pre>" . print_r($_POST) . "</pre>";
    $ID = $lastHospitalID;
    $messages = $_POST['messages'];
    $response = $_POST['response'];
    $Stat->execute();
    echo '<div class="alert alert-success m-0 p-0 text-center font-weight-bold">تمت الاضافة بنجاح</div>';
}
?>
<div class="row">
    <div class="col-12" dir="rtl">
        <br />
        <hr />
        <h4 style="display: inline-block;">
            <i class="fa fa-hospital-o"></i>
            أضافة الى
            <br />
            <?php echo $chatInfo[0]; ?>
        </h4>

        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <form action="<?php echo $path . 'addChat.php?HospitalChat=' . $chatInfo[2]; ?>" method="POST"
            style="padding-right: 60px;margin-bottom:70px">
            <div class="form-group text-right">
                <textarea class="form-control" placeholder="الأستفسار...." name="messages" rows="4"></textarea>
            </div>
            <div class="form-group text-right">
                <textarea class="form-control" placeholder="الرد......" name="response" rows="4"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">أرسال</button>
        </form>

        <br />
        <br />
        <hr />
    </div>
</div>