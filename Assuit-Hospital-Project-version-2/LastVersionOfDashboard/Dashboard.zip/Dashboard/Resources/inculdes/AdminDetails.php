<?php
$adminId = intval($GLOBALS['Admin_Id']);
$check = ChickItem('ID', 'Admin', $adminId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا المشرف غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_Admin =  SelectWhereID('Admin', $adminId);
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-primary">تفاصيل عن المشرف</h1>
        <h2><span class="text-primary">أسم المشرف: </span><?php echo $the_Admin[0]['Name']; ?></h2>
        <h2><span class="text-primary"> درجة المشرف: </span>
            <?php
            if ($the_Admin[0]['SuperAdmin'] == 1)
                echo "مشرف رئيسي";
            else
                echo "مشرف عادي";
            ?>
        </h2>
        <h5><span class="text-primary">صورة:</span><br /><?php echo $the_Admin[0]['Img']; ?></h5>
        <hr />
        <a href="<?php echo $path; ?>Admins.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-puzzle-piece"></i>
            عودة لصفحة المشرفين
        </a>
        &#160;&#160;
        <a href="<?php echo $path; ?>Welcome.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
    </div>
</div>