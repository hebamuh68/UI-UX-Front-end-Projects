<?php
$lastHospitalID = getLastID('Hospital') + 1;

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if( StringEmpty($_POST['Hospital_Name']) )
    {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    }else{
    //Error Here
    $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //global $connection;
    $Stat = $conn->prepare("INSERT INTO Hospital (ID,`Name`,About,Vision,Map,MediaID,DepartmentID,GroupID) 
    VALUES (:ID,:Hospital_Name,:About,:Vision,:Map,:MediaID,:DepartmentID,:GroupID)");
    $Stat->bindParam(':ID', $lastHospitalID);
    $Stat->bindParam(':Hospital_Name', $Hospital_Name);
    $Stat->bindParam(':About', $About);
    $Stat->bindParam(':Vision', $Vision);
    $Stat->bindParam(':Map', $Map);
    $Stat->bindParam(':MediaID', $MediaID);
    $Stat->bindParam(':DepartmentID', $DepartmentID);
    $Stat->bindParam(':GroupID', $GroupID);
    $ID = $lastHospitalID;
    $Hospital_Name = $_POST['Hospital_Name'];
    $About = $_POST['About'];
    $Vision = $_POST['Vision'];
    $Map = $_POST['Map'];
    $MediaID = NULL;
    $DepartmentID = NULL;
    $GroupID = NULL;
    $Stat->execute();
    echo '<div class="alert alert-success">تمت أضافة المستشفي بنجاح</div>';
    }
}
?>
<div class="row mt-4" dir="rtl">
    <h2 class="col-12">إضافة مستشفى جديد</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $lastHospitalID + 1; ?>" />
            <div class="form-group">
                <label for="Hospital_Name">اسم المستشفى </label>
                <input type="text" class="form-control" id="Hospital_Name" required placeholder="أدخل اسم المستشفى"
                    name="Hospital_Name">
            </div>
            <div class="form-group">
                <label for="About">عن المستشفى </label>
                <input type="text" class="form-control" id="About" required placeholder="ادخل نبذة مختصرة عن المستشفى"
                    name="About">
            </div>
            <div class="form-group">
                <label for="Vision">رؤية المستشفى </label>
                <input type="text" class="form-control" id="Vision" required placeholder="رؤية المستشفى" name="Vision">
            </div>
            <div class="form-group">
                <label for="Map">خريطة المستشفى </label>
                <input type="text" class="form-control" id="Map" required placeholder="خريطة المستشفى" name="Map">
            </div>
            <button type="submit" class="btn btn-primary">إضافة المستشفى</button>
            &#160;
            <a href="<?php echo $path; ?>Hospitals.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة المستشفيات
            </a>
        </form>
    </div>
</div>