<?php

$departmentId = intval($GLOBALS['department_ID']);
$check = ChickItem('ID', 'Department', $departmentId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا القسم غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_Department =  SelectWhereID('Department', $departmentId);
    $Hosp =  SelectWhereID('Hospital', $the_Department[0]['HospitalID']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $departmentId = $_POST['departmentId'];
    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // construct the delete statement
    $sql = 'DELETE FROM Department
            WHERE ID = :departmentId';

    // prepare the statement for execution
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':departmentId', $departmentId, PDO::PARAM_INT);

    // execute the statement
    if ($statement->execute()) {
        echo '<div class="alert alert-danger">';
        echo '<p class="lead">عملية الحذف تمت بنجاح سيتم توجيهك الى صفحة الأقسام الأن</p>';
        echo '</div>';
        header("refresh:0; url=departments.php");
    }
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-danger text-center">حذف قسم</h1>
        <h2><span class="text-primary">أسم القسم: </span><?php echo $the_Department[0]['Name']; ?></h2>
        <h5><span class="text-primary">القسم خاص بمستشفي:</span><?php echo $Hosp[0]['Name']; ?></h5>
        <h5><span class="text-primary">عن القسم:</span><?php echo $the_Department[0]['About']; ?></h5>
        <hr />
        <a href="<?php echo $path; ?>departments.php" type="button" class="text-white btn btn-success">
            <i class="fa fa-Departmentpaper-o"></i>
            عودة لصفحة الأقسام
        </a>
        &#160;&#160;
        <form class="d-inline"
            action="<?php echo $_SERVER['PHP_SELF'] . '?do=Delete&Department_ID=' . $departmentId; ?>" method="POST">
            <input type="hidden" name="departmentId" value="<?php echo $departmentId; ?>" />
            <button type="submit" class="text-white btn btn-danger">
                <i class='fa fa-trash-o' aria-hidden='true'></i>
                حذف القسم
            </button>
        </form>
    </div>
</div>