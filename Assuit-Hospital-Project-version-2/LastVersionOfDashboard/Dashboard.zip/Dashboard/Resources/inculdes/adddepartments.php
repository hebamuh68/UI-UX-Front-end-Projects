<?php
$lastdepartmentID = getLastID('Department') + 1;
$hospitals = getAll('ID,Name', 'Hospital', 'ID');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if( StringEmpty($_POST['Specialization']))
    {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    }else{
    //Error Here
    $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //global $connection;
    $Stat = $conn->prepare("INSERT INTO Department (ID,Specialization,`Name`,About,HospitalID,MediaID,ClinicID) 
    VALUES (:ID,:Specialization,:DName,:About,:HospitalID,:MediaID,:ClinicID)");
    $Stat->bindParam(':ID', $lastdepartmentID);
    $Stat->bindParam(':Specialization', $departmentSpecialization);
    $Stat->bindParam(':DName', $departmentName);
    $Stat->bindParam(':About', $Aboutdepartment);
    $Stat->bindParam(':MediaID', $MediaID);
    $Stat->bindParam(':ClinicID', $ClinicID);
    $Stat->bindParam(':HospitalID', $HospitalID);
    $departmentID = $_POST['ID'];
    $departmentSpecialization = $_POST['Specialization'];
    $departmentName = $_POST['Name'];
    $Aboutdepartment = $_POST['About'];
    $HospitalID = $_POST['HospitalID'];
    $MediaID = NULL;
    $ClinicID = NULL;
    $Stat->execute();
    echo '<div class="alert alert-success">تمت أضافة القسم بنجاح</div>';
    }
}
?>
<div class="row mt-4" dir="rtl">
    <h2 class="col-12">أضافة قسم جديد</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $lastdepartmentID; ?>" />
            <div class="form-group">
                <label for="Specialization"> اسم القسم </label>
                <input type="text" class="form-control" id="Specialization" required placeholder="أدخل القسم"
                    name="Name">
            </div>
            <div class="form-group">
                <label for="Title"> تخصص القسم </label>
                <input type="text" class="form-control" id="Specialization" required
                    placeholder="التخصص مثل :الجراحه العامه " name="Specialization">
            </div>
            <div class="form-group">
                <label for="HospitalID">القسم خاص بمستشفيى </label>
                <select id="HospitalID" name="HospitalID" class="form-control">
                    <?php
                    foreach ($hospitals as $h) {
                        echo '<option value=' . $h['ID'] . '>' . $h['Name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="About"> عن القسم </label>
                <textarea type="text" class="form-control" id="About" placeholder="تفاصيل عن القسم"
                    name="About"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">أضافة قسم</button>
            &#160;
            <a href="<?php echo $path; ?>departments.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة الأقسام
            </a>
        </form>
    </div>
</div>