<div class="row">
    <div class="col-12" dir="rtl">
        <br />
        <hr />
        <h4 style="display: inline-block;">
            <i class="fa fa-hospital-o"></i>
            عرض الأحداث القادمة
        </h4>

        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <a href="<?php echo $path; ?>Events.php?do=add" style="float: left;margin-top: -5px;" type="button"
            class="btn btn-info text-white"> أضافة حدث
            <i class="fa fa-plus" aria-hidden="true"></i>
        </a>
        <!--Tables-->
        <table class="table table-striped  table-hover" dir="rtl">
            <thead>
                <tr dir="rtl">
                    <th>الحدث</th>
                    <th>التاريخ</th>
                    <th>المكان</th>
                    <th>التحكم</th>
                </tr>
            </thead>

            <tbody>
                <?php
                foreach ($events as  $Item) {
                    echo "<tr>";
                    echo "<td>" . $Item['title'] . "</td>";
                    echo "<td>" . $Item['date'] . "</td>";
                    echo "<td>" . $Item['loc'] . "</td>";
                    echo "<td>
                            <a href='?do=Show&event_ID=" . $Item['id'] . "' class='btn btn-warning'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-eye' aria-hidden='true'></i>
                            تفاصيل</a>
                            <a href='?do=edit&event_ID=" . $Item['id'] . "' class='btn btn-success'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-pencil' aria-hidden='true'></i>
                            تعديل</a>
                            <a href='?do=Delete&event_ID=" . $Item['id'] . "' class='btn btn-danger confirm'><span class=\"glyphicon glyphicon-remove\"></span>
                            <i class='fa fa-trash-o' aria-hidden='true'></i>حذف</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <br />
        <br />
        <hr />
    </div>
</div>