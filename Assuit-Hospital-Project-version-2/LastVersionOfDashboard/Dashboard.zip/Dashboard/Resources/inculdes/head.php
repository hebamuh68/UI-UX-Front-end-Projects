<!DOCTYPE html>
<html>

<head>
    <!--set meta data about website-->
    <!--Charset-->
    <meta charset="UTF-8" />
    <!--Description-->
    <meta name="description" content="Assuit Hospitals" />
    <!--viewport-->
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <!--Title of website-->
    <title><?php putPageTitle(); ?></title>
    <!--import Bootstrap css files.-->
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/css/bootstrap.min.css"
        integrity="sha384-Gn5384xqQ1aoWXA+058RXPxPg6fy4IWvTNh0E263XmFcJlSAwiGgFAW/dAiS6JXm" crossorigin="anonymous">
    <!-- offline bootstrab -->
    <!--start import bootstrap files offline-->

    <link rel="stylesheet" href="Resources/bootstrap-4.5.3-dist/css/bootstrap.min.css">
    <script src="Resources/bootstrap-4.5.3-dist/js/bootstrap.min.js"></script>

    <!--end  import bootstrap files offline-->
    <!--import font icon-->
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/4.7.0/css/font-awesome.min.css">
    <!--import css style-->
    <link rel="stylesheet" href="Resources/css/myStyle.css" />
    <!--import font-->
    <link href="http://fonts.cdnfonts.com/css/tajawal" rel="stylesheet">
    <!-- HTML5 shim and Respond.js IE8 support of HTML5 elements and media queries -->
    <!--[if lt IE 9]>
          <script src="bootstrap-3.0.0/assets/js/html5shiv.js"></script>
          <script src="bootstrap-3.0.0/assets/js/respond.min.js"></script>
        <![endif]-->
</head>

<body style="font-family: Tajawal;">