<?php

$artical_ID = intval($GLOBALS['artical_ID']);
$check = ChickItem('id', 'artical', $artical_ID);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا المقال غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_Artical =  SelectWhereID('artical', $artical_ID);
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    if (
        StringEmpty($_POST['title'])
        || StringEmpty($_POST['keywords'])
        || StringEmpty($_POST['about_re'])
        || StringEmpty($_POST['doctor_name'])
        || StringEmpty($_POST['email'])
        || StringEmpty($_POST['phone'])
    ) {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    } else {
        //Error Here
        $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
        // set the PDO error mode to exception
        $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
        //global $connection;

        $Stat = $conn->prepare("UPDATE artical 
                                SET
                                title = :title, 
                                keywords = :keywords, 
                                about_re = :about_re, 
                                doctor_name = :doctor_name, 
                                phone = :phone, 
                                `date` = :MyDate, 
                                email = :email 
                                WHERE id = $artical_ID");
        $Stat->bindParam(':title', $title);
        $Stat->bindParam(':keywords', $keywords);
        $Stat->bindParam(':about_re', $about_re);
        $Stat->bindParam(':doctor_name', $doctor_name);
        $Stat->bindParam(':phone', $phone);
        $Stat->bindParam(':MyDate', $MyDate);
        $Stat->bindParam(':email', $email);
        $title = $_POST['title'];
        $keywords = $_POST['keywords'];
        $MyDate = $_POST['date'];
        $about_re = $_POST['about_re'];
        $doctor_name = $_POST['doctor_name'];
        $phone = $_POST['phone'];
        $email = $_POST['email'];
        $Stat->execute();
        echo '<div class="alert alert-success">تمت تعديل المقال بنجاح</div>';
    }
}
$res =  SelectWhereID('artical', $artical_ID);
?>
<div class="row mt-4" dir="rtl">
    <h2 class="col-12">تعديل مقال</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=edit&artical_ID=' . $artical_ID; ?>" method="POST"
            enctype="multipart/form-data">
            <h5>1 - معلومات عن المقال :</h5>
            <div class="item">
                <p>عنوان المقال<span class="required">*</span></p>
                <input type="text" value="<?php echo $res[0]['title']; ?>" class="form-control" name="title" required />
            </div>
            <div class="item">
                <p>العناوين الرئيسيه<span class="required">*</span></p>
                <input class="form-control" type="text" value="<?php echo $res[0]['keywords']; ?>" name="keywords" />
            </div>
            <div class="item">
                <p>عن المقال ؟ <span class="required">*</span></p>
                <input class="form-control" type="text" value="<?php echo $res[0]['about_re']; ?>" name="about_re"
                    required />
            </div>
            <div class="item">
                <p>تاريخ النشر</p>
                <input class="form-control" type="date" value="<?php echo $res[0]['date']; ?>" name="date" />
                <i class="fas fa-calendar-alt"></i>
            </div>
            <h5>2 - معلومات عن الطبيب الناشر :</h5>
            <div class="item">
                <p>الاسم <span class="required">*</span></p>
                <input class="form-control" type="text" value="<?php echo $res[0]['doctor_name']; ?>" name="doctor_name"
                    required placeholder="Dr/" />
            </div>
            <div class="item">
                <p>البريد الإلكترونى<span class="required">*</span></p>
                <input class="form-control" type="text" value="<?php echo $res[0]['email']; ?>" name="email"
                    placeholder="@" required />
            </div>
            <div class="item">
                <p>رقم الهاتف<span class="required">*</span></p>
                <input class="form-control" type="text" value="<?php echo $res[0]['phone']; ?>" name="phone" required />
            </div>
            <div class="btn-block" style="margin-top: 20px;">
                <button type="submit" class="btn btn-primary">تعديل المقال</button>
                &#160;
                <a href="<?php echo $path; ?>Articals.php" type="button" class="text-white btn btn-primary">
                    <i class="fa fa-newspaper-o"></i>
                    عودة لصفحة المقالات
                </a>
            </div>


        </form>
    </div>
</div>