<?php
$newsId = intval($GLOBALS['News_ID']);
$check = ChickItem('ID', 'News', $newsId);

if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا الخبر غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_news =  SelectWhereID('News', $GLOBALS['News_ID']);
    $hospital = SelectWhereID('Hospital', $GLOBALS['News_ID']);
}
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $newsId = $_POST['NewsID'];
    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // construct the delete statement
    $sql = 'DELETE FROM News
            WHERE ID = :NewsID';

    // prepare the statement for execution
    $statement = $pdo->prepare($sql);
    $statement->bindParam(':NewsID', $newsId, PDO::PARAM_INT);

    // execute the statement
    if ($statement->execute()) {
        echo '<div class="alert alert-danger">';
        echo '<p class="lead">عملية الحذف تمت بنجاح سيتم توجيهك الى صفحة الاخبار الأن</p>';
        echo '</div>';
        header("refresh:1; url=News.php");
    }
}
?>

<div class="row d-inline">
    <div class="col-11 m-auto">
        <h1 class="text-danger text-center">حذف خبر</h1>
        <h2><span class="text-primary">عنوان الخبر : </span><?php echo $the_news[0]['Title']; ?></h2>
        <h4><span class="text-primary">الخبر خاص بالمستشفي :</span><?php echo $hospital[0]['Name']; ?></h4>
        <h5><span class="text-primary">تاريخ الخبر :</span><?php echo $the_news[0]['NewsDate']; ?></h5>
        <hr />
        <h6 class="text-primary">تفاصيل الخبر</h6>
        <p class="lead"><?php echo $the_news[0]['Content']; ?></p>
        <hr />
        <a href="<?php echo $path; ?>News.php" type="button" class="text-white btn btn-success">
            <i class="fa fa-newspaper-o"></i>
            عودة لصفحة الأخبار
        </a>
        &#160;&#160;
        <form class="d-inline" action="<?php echo $_SERVER['PHP_SELF'] . '?do=Delete&News_ID=' . $newsId; ?>"
            method="POST">
            <input type="hidden" name="NewsID" value="<?php echo $newsId; ?>" />
            <button type="submit" class="text-white btn btn-danger">
                <i class='fa fa-trash-o' aria-hidden='true'></i>
                حذف الخبر
            </button>
        </form>
    </div>
</div>