<div class="row">
    <div class="col-12">
        <br />
        <hr />
        <h4 style="display: inline-block;">
            <i class="fa fa-puzzle-piece"></i>
            المشرفين
        </h4>
        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <?php
        if ($_SESSION['SuperAdmin'] == 1) {
            echo   '<a href="' . $path . 'Admins.php?do=add" style="float: left;margin-top: -5px;" type="button"
        class="btn btn-info text-white"> أضافة مشرف
        <i class="fa fa-plus" aria-hidden="true"></i>
        </a>';
        }
        ?>

        <!--Tables-->
        <table class="table table-striped  table-hover" dir="rtl">
            <thead>
                <tr dir="rtl">
                    <th> ID </th>
                    <th> اسم المشرف</th>
                    <th> الأيميل </th>
                    <th>
                        تحكم
                    </th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($admins as  $Item) {
                    echo "<tr>";
                    echo "<td>" . $Item['ID'] . "</td>";
                    if ($Item['SuperAdmin'] == 1) {
                        echo "<td><small class='text-info'>المشرف الرئيسي : </small>" . $Item['Name'] . "</td>";
                    } else {
                        echo "<td>" . $Item['Name'] . "</td>";
                    }
                    echo "<td>" . $Item['Email'] . "</td>";
                    echo "<td>
                            <a href='?do=Show&Admin_Id=" . $Item['ID'] . "' class='btn btn-warning'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-eye' aria-hidden='true'></i>
                            تفاصيل</a>";
                    if ($_SESSION['SuperAdmin'] == 1) {
                        echo    " <a href='?do=edit&Admin_Id=" . $Item['ID'] . "' class='btn btn-success'><span class=\"glyphicon glyphicon-edit\"></span>
                            <i class='fa fa-pencil' aria-hidden='true'></i>
                            تعديل</a>
                            <a href='?do=Delete&Admin_Id=" . $Item['ID'] . "' class='btn btn-danger confirm'><span class=\"glyphicon glyphicon-remove\"></span>
                            <i class='fa fa-trash-o' aria-hidden='true'></i>حذف</a>";
                    }
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>

        <br />
        <br />
        <hr />
    </div>
</div>