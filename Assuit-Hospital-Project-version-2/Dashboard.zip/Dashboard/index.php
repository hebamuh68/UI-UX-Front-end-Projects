<?php

//import pathes page
include 'connection.php';

//start session
session_start();

//start to chick if if there is a session or not 
if (isset($_SESSION['User_Name'])) {

    //realy logged in
    header("Location:Welcome.php");

    exit();
}

//chick if user come from http post method
if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $User_Email     = $_POST['User_Email'];
    $User_Password  = $_POST['User_Password'];
    $password       = md5($User_Password);

    //start to connect with data base

    $sql_statment  = $connection->prepare("SELECT `Name`,`Email`,`Password`,`SuperAdmin`,`ID` FROM `Admin` WHERE `Email`=? AND`Password` = ?  LIMIT 1");

    $sql_statment->execute(array($User_Email, $password));

    $res_counter = $sql_statment->rowCount();

    if ($res_counter == 1) {

        $row = $sql_statment->fetch();       //that lead to store data from data base in array called $row

        $_SESSION['User_ID']   = $row['ID'];   //register User_ID on session 
        $_SESSION['User_Name']   = $row['Name'];
        $_SESSION['SuperAdmin'] = $row['SuperAdmin'];
        header("Location:Welcome.php");       // redirect my to welcome.php page

        exit();       // to end script here

    } else if ($res_counter == 0) {
        echo "<center style='color:red'>خطا فى اسم المستخدم او كلمة المرور</center>";
    } else {

        echo $res_counter . "I think there is an error ";
    }
} #end if for send by post way....


?>


<!DOCTYPE html>
<html>

<head>
    <meta charset="utf-8" />
    <title>تسجيل الدخول</title>
    <link href="Resources/css/loginStyle.css" rel="stylesheet" />
    <link href="https://fonts.googleapis.com/css?family=Indie+Flower|Overpass+Mono" rel="stylesheet">
</head>

<body>
    <div id="wrapper">
        <div class="main-content">
            <div class="header">
                <h1 style="color: #3897f0;margin-bottom: 20px;" dir="rtl">تسجيل الدخول</h1>
            </div>
            <form action="<?php echo $_SERVER['PHP_SELF'] ?>" method="POST">
                <div class="l-part">
                    <input type="email" name="User_Email" dir="rtl" placeholder="أدخل الأيميل" class="input-1" />
                    <div class="overlap-text">
                        <input type="password" name="User_Password" dir="rtl" placeholder="كلمة المرور"
                            class="input-2" />
                        <a href="#">نسيت؟</a>
                    </div>
                    <input type="submit" value="دخول" class="btn" />
                </div>
            </form>
        </div>
    </div>

</body>

</html>