<?php

$clinicId = intval($GLOBALS['Clinic_ID']);
$check = ChickItem('ID', 'Clinic', $clinicId);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه العيادة غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $res =  SelectWhereID('Clinic', $clinicId);
    $Dept =  SelectWhereID('Department', $res[0]['Dept_ID']);
}

?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12 text-primary"> بيانات العيادة</h2>
    <div class="col-12">
        <h4><span class="text-primary">تخصص العيادة : </span>
            <?php echo $res[0]['Specialization'] ? $res[0]['Specialization'] : ""; ?>
        </h4>
        <h4><span class="text-primary">عن العيادة :</span>
            <?php echo $res[0]['About'] ? $res[0]['About'] : ""; ?>
        </h4>
        <h4><span class="text-primary">العيادة خاصة بقسم :</span>
            <?php echo $Dept[0]['Name'] ? $Dept[0]['Name'] : ""; ?>
        </h4>
        <a href="<?php echo $path; ?>Clinic.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-newspaper-o"></i>
            عودة لعرض العيادات
        </a>
    </div>
</div>