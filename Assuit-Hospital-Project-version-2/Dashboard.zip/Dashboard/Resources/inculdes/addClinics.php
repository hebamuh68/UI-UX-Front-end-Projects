<?php
$lastClinicID = getLastID('Clinic') + 1;
$departments  = getAll('ID,Name', 'Department', 'ID');
//$hospitals = getAll('`ID`, `Specialization`, `About`, `MediaID`, `PersonID`','clinic','ID');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if( StringEmpty($_POST['Specialization']))
    {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    }else{
    //Error Here
    $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //global $connection;
    $Stat = $conn->prepare("INSERT INTO Clinic (`ID`, `Specialization`, `About`, `MediaID`, `PersonID`,`Dept_ID`) 
    VALUES (:ID,:Specialization,:About,:MediaID,:PersonID,:Dept_ID)");
    $Stat->bindParam(':ID', $lastClinicID);
    $Stat->bindParam(':Specialization', $Specialization);
    $Stat->bindParam(':About', $About);
    $Stat->bindParam(':MediaID', $MediaID);
    $Stat->bindParam(':PersonID', $PersonID);
    $Stat->bindParam(':Dept_ID', $Dept_ID);
    $ID = $lastClinicID;
    $Specialization = $_POST['Specialization'];
    $About = $_POST['About'];
    $Dept_ID = $_POST['Dept_ID'];
    $MediaID = NULL;
    $PersonID = NULL;
    $Stat->execute();
    echo '<div class="alert alert-success">تمت أضافة عيادة بنجاح</div>';
    }
}
?>
<div class="row mt-4" dir="rtl">
    <h2 class="col-12">إضافة عيادة جديدة</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $lastClinicID + 1; ?>" />
            <div class="form-group">
                <label for="Specialization">اسم العيادة </label>
                <input type="text" class="form-control" id="Specialization" required placeholder="أدخل تخصص العيادة"
                    name="Specialization">
            </div>
            <div class="form-group">
                <label for="About">عن العيادة </label>
                <input type="text" class="form-control" id="About" required placeholder="ادخل نبذة مختصرة عن العيادة"
                    name="About">
            </div>
            <div class="form-group">
                <label for="Dept_ID">العيادة خاصة بقسم  </label>
                <select id="Dept_ID" name="Dept_ID" class="form-control">
                    <?php
                    foreach ($departments as $h) {
                        echo '<option value=' . $h['ID'] . '>' . $h['Name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">إضافة العيادة</button>
            &#160;
            <a href="<?php echo $path; ?>Clinic.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة المشرفين
            </a>
        </form>
    </div>
</div>