<?php
$lastNewsID = getLastID('News') + 1;
$hospitals = getAll('ID,Name', 'Hospital', 'ID');
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if( StringEmpty($_POST['NewsDate']) || StringEmpty($_POST['Title']))
    {
        echo '<div class="alert alert-danger">خطا فى تدخيل البيانات</div>';
    }else{
    //Error Here
    $conn = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    // set the PDO error mode to exception
    $conn->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);
    //global $connection;
    $Stat = $conn->prepare("INSERT INTO News(ID,NewsDate,Title,Content,MediaID,HospitalID) 
        VALUES (:ID,:NewsDate,:Title,:Content,:MediaID,:HospitalID)");
    $Stat->bindParam(':ID', $lastNewsID);
    $Stat->bindParam(':NewsDate', $NewsDate);
    $Stat->bindParam(':Title', $Title);
    $Stat->bindParam(':Content', $Content);
    $Stat->bindParam(':MediaID', $MediaID);
    $Stat->bindParam(':HospitalID', $HospitalID);
    $ID = $_POST['ID'];
    $NewsDate = $_POST['NewsDate'];
    $Title = $_POST['Title'];
    $Content = $_POST['Content'];
    $MediaID = NULL;
    $HospitalID = $_POST['HoptialID'];
    $Stat->execute();
    echo '<div class="alert alert-success">تمت أضافة الخبر بنجاح</div>';
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">أضافة خبر جديد</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=add'; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $lastNewsID + 1; ?>" />
            <div class="form-group">
                <label for="NewsDate">تاريخ الخبر </label>
                <input type="text" class="form-control" id="NewsDate" required placeholder="أدخل التاريخ مثل:22-4-2020"
                    name="NewsDate">
            </div>
            <div class="form-group">
                <label for="Title">عنوان الخبر </label>
                <input type="text" class="form-control" id="Title" required placeholder="عنوان الخبر مثال:زيارة هامة"
                    name="Title">
            </div>
            <div class="form-group">
                <label for="HoptialID">الخبر خاص بمستشفيى </label>
                <select id="HoptialID" name="HoptialID" class="form-control">
                    <?php
                    foreach ($hospitals as $h) {
                        echo '<option value=' . $h['ID'] . '>' . $h['Name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="Content">متحتوي الخبر </label>
                <textarea type="text" class="form-control" id="Content" placeholder="تفاصيل الخبر"
                    name="Content"></textarea>
            </div>
            <button type="submit" class="btn btn-primary">أضافة الخبر</button>
            &#160;
            <a href="<?php echo $path; ?>News.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة الأخبار
            </a>
        </form>
    </div>
</div>