<?php

$newsId = intval($GLOBALS['News_ID']);
$check = ChickItem('ID', 'News', $newsId);
$res =  SelectWhereID('News', $GLOBALS['News_ID']);
$hospitals = getAll('ID,Name', 'Hospital', 'ID');
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا الخبر غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // echo "<pre dir='ltr'>" . print_r($_POST) . "</pre>";

    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = 'UPDATE  News
            SET NewsDate = :NewsDate,
                Title    = :Title ,
                Content  = :Content,
                HospitalID = :HospitalID
            WHERE ID = :ID';
    // echo "after step 1 ok!";
    $statement = $pdo->prepare($sql);
    //echo "after step 2 ok!";
    $statement->bindParam(':ID', $ID, PDO::PARAM_INT);
    $statement->bindParam(':NewsDate', $NewsDate);
    $statement->bindParam(':Title', $Title);
    $statement->bindParam(':Content', $Content);
    $statement->bindParam(':HospitalID', $HospitalID);
    $ID = $_POST['ID'];
    $NewsDate = $_POST['NewsDate'];
    $Title = $_POST['Title'];
    $Content = $_POST['Content'];
    $MediaID = NULL;
    $HospitalID = $_POST['HoptialID'];
    //echo "after step 3 ok!";
    if ($statement->execute()) {
        echo "<div class='alert alert-success'>تم التعديل بنجاح</div>";
        $res =  SelectWhereID('News', $GLOBALS['News_ID']);
    } else {
        echo "error in execution of statment";
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">تعديل خبر</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=edit&News_ID=' . $newsId; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $res[0]['ID']; ?>" />
            <div class="form-group">
                <label for="NewsDate">تاريخ الخبر </label>
                <input value="<?php echo $res[0]['NewsDate'] ? $res[0]['NewsDate'] : ""; ?>" type="text"
                    class="form-control" id="NewsDate" required placeholder="أدخل التاريخ مثل:22-4-2020"
                    name="NewsDate">
            </div>
            <div class="form-group">
                <label for="Title">عنوان الخبر </label>
                <input value="<?php echo $res[0]['Title'] ? $res[0]['Title'] : ""; ?>" type="text" class="form-control"
                    id="Title" required placeholder="عنوان الخبر مثال:زيارة هامة" name="Title">
            </div>
            <div class="form-group">
                <label for="HoptialID">الخبر خاص بمستشفيى </label>
                <select value="<?php $res[0]['HospitalID']; ?>" id="HoptialID" name="HoptialID" class="form-control">
                    <?php
                    foreach ($hospitals as $h) {
                        echo '<option value="' . $h['ID'] . '"'; //. '>' . $h['Name'] . '</option>';
                        if ($h['ID'] == $res[0]['HospitalID'])
                            echo "selected";
                        //if($row['StatEditNewsus'] == 0){echo 'selcted';}
                        echo '>' . $h['Name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="Content">متحتوي الخبر </label>
                <textarea type="text" class="form-control" id="Content" placeholder="تفاصيل الخبر"
                    name="Content"><?php echo $res[0]['Content'] ? $res[0]['Content'] : ""; ?></textarea>
            </div>
            <button type="submit" class="btn btn-primary">تعديل الخبر</button>
            &#160;
            <a href="<?php echo $path; ?>News.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لصفحة الأخبار
            </a>
        </form>
    </div>
</div>