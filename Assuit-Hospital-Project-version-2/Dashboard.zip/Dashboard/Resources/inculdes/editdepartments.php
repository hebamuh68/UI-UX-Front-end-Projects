<?php

$departmentId = intval($GLOBALS['department_ID']);
$check = ChickItem('ID', 'Department', $departmentId);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا القسم غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $res =  SelectWhereID('Department', $departmentId);
    $hospitals = getAll('ID,Name', 'Hospital', 'ID');
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {

    $pdo = new PDO('mysql:host=localhost;dbname=AssuitHospitals', 'root', '');
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    $sql = 'UPDATE  Department
            SET `Name` = :Depart_Name,
                About    = :About ,
                Specialization  = :Specialization,
                HospitalID = :HospitalID
            WHERE ID = :ID';
    // echo "after step 1 ok!";
    $statement = $pdo->prepare($sql);
    //echo "after step 2 ok!";
    $statement->bindParam(':ID', $ID, PDO::PARAM_INT);
    $statement->bindParam(':Depart_Name', $Depart_Name);
    $statement->bindParam(':About', $About);
    $statement->bindParam(':Specialization', $Specialization);
    $statement->bindParam(':HospitalID', $HospitalID);
    $ID = $_POST['ID'];
    $Depart_Name = $_POST['Name'];
    $About = $_POST['About'];
    $Specialization = $_POST['Specialization'];
    $HospitalID = $_POST['HospitalID'];
    //echo "after step 3 ok!";
    if ($statement->execute()) {
        echo "<div class='alert alert-success'>تم التعديل بنجاح</div>";
        $res =  SelectWhereID('Department', $departmentId);
    } else {
        echo "error in execution of statment";
    }
}
?>

<div class="row mt-4" dir="rtl">
    <h2 class="col-12">تعديل بيانات القسم</h2>
    <div class="col-12">
        <form action="<?php echo $_SERVER['PHP_SELF'] . '?do=edit&department_ID=' . $departmentId; ?>" method="POST">
            <input type="hidden" name="ID" value="<?php echo $res[0]['ID']; ?>" />

            <div class="form-group">
                <label for="Hospital_Name">اسم القسم </label>
                <input value="<?php echo $res[0]['Name'] ? $res[0]['Name'] : ""; ?>" type="text" class="form-control"
                    id="Name" required placeholder="أدخل اسم القسم" name="Name">
            </div>
            <div class="form-group">
                <label for="Vision">تخصص القسم</label>
                <input value="<?php echo $res[0]['Specialization'] ? $res[0]['Specialization'] : ""; ?>" type="text"
                    class="form-control" id="Specialization" required placeholder="رؤية المستشفى" name="Specialization">
            </div>
            <div class="form-group">
                <label for="HospitalID">القسم خاص بمستشفيى </label>
                <select id="HospitalID" name="HospitalID" class="form-control">
                <?php
                    foreach ($hospitals as $h) {
                        echo '<option value="' . $h['ID'] . '"'; //. '>' . $h['Name'] . '</option>';
                        if ($h['ID'] == $res[0]['HospitalID'])
                            echo "selected";
                        //if($row['StatEditNewsus'] == 0){echo 'selcted';}
                        echo '>' . $h['Name'] . '</option>';
                    }
                    ?>
                </select>
            </div>
            <div class="form-group">
                <label for="About">عن لقسم </label>
                <input value="<?php echo $res[0]['About'] ? $res[0]['About'] : ""; ?>" type="text" class="form-control"
                    id="About" required placeholder="ادخل نبذة مختصرة عن القسم" name="About">
            </div>

            <button type="submit" class="btn btn-primary">تعديل القسم</button>
            &#160;
            <a href="<?php echo $path; ?>departments.php" type="button" class="text-white btn btn-primary">
                <i class="fa fa-newspaper-o"></i>
                عودة لعرض الأقسام
            </a>
        </form>
    </div>
</div>