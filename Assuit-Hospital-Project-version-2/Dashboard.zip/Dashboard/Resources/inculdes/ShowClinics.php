<div class="row">
    <div class="col-12">
        <br />
        <hr />
        <h4 style="display: inline-block;">
            <i class="fa fa-newspaper-o"></i>
            عرض العيادات
        </h4>
        <a href="<?php echo $path; ?>Welcome.php" style="float: left;margin-right:2px;margin-top: -5px;" type="button"
            class="text-white btn btn-info">
            <i class="fa fa-home"></i>
            عودة لصفحة الرئيسية
        </a>
        <a href="<?php echo $path; ?>Clinic.php?do=add" style="float: left;margin-top: -5px;" type="button"
            class="btn btn-info text-white">إضافة عيادة
            <i class="fa fa-plus" aria-hidden="true"></i>
        </a>
        <!--Tables-->
        <table class="table table-striped  table-hover" dir="rtl">
            <thead>
                <tr dir="rtl">
                    <th>#</th>

                    <th>تخصص العيادة</th>
                    <th>عن العيادة</th>

                    <th>تحكم</th>
                </tr>
            </thead>
            <tbody>
                <?php
                foreach ($clinic as  $Item) {
                    echo "<tr>";
                    echo "<td>" . $Item['ID'] . "</td>";
                    echo "<td>" . $Item['Specialization'] . "</td>";
                    echo "<td>" . $Item['About'] . "</td>";
                    echo "<td>
	                            <a href='?do=Show&Clinic_ID=" . $Item['ID'] . "' class='btn btn-warning'><span class=\"glyphicon glyphicon-edit\"></span>
	                            <i class='fa fa-eye' aria-hidden='true'></i>
	                            تفاصيل</a>
	                            <a href='?do=edit&Clinic_ID=" . $Item['ID'] . "' class='btn btn-success'><span class=\"glyphicon glyphicon-edit\"></span>
	                            <i class='fa fa-pencil' aria-hidden='true'></i>
                            تعديل</a>
                            <a href='?do=Delete&Clinic_ID=" . $Item['ID'] . "' class='btn btn-danger confirm'><span class=\"glyphicon glyphicon-remove\"></span>
	                            <i class='fa fa-trash-o' aria-hidden='true'></i>
	حذف</a>";
                    echo "</td>";
                    echo "</tr>";
                }
                ?>
            </tbody>
        </table>
        <br />
        <br />
        <hr />
    </div>
</div>