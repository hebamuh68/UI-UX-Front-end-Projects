<?php
$hospitalId = intval($GLOBALS['Hospital_ID']);
$check = ChickItem('ID', 'Hospital', $hospitalId);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذه المستشفي غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:1; url=Welcome.php");
} else {
    $hospital =  SelectWhereID('Hospital', $GLOBALS['Hospital_ID']);
}
?>
<div class="row d-inline">
    <div class="col-11 m-auto">
        <h2><span class="text-primary">أسم المستشفي : </span><?php echo $hospital[0]['Name']; ?></h2>
        <h5><span class="text-primary">عن المستشفي :</span></h5>
        <p class="lead"><?php echo $hospital[0]['About']; ?></p>
        <h5><span class="text-primary">روية الميتشفي :</span></h5>
        <p class="lead"><?php echo $hospital[0]['Vision']; ?></p>
        <hr />
        <h5><span class="text-primary">خريطة الميتشفي :</span></h5>
        <p class="lead"><?php echo $hospital[0]['Map']; ?></p>
        <hr />
        <a href="<?php echo $path; ?>Welcome.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-home"></i>
            الصفحة الرئيسية
        </a>
        &#160;&#160;
        <a href="<?php echo $path; ?>Hospitals.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-newspaper-o"></i>
            المستشفيات
        </a>
    </div>
</div>