<?php
$newsId = intval($GLOBALS['News_ID']);
$check = ChickItem('ID', 'News', $newsId);
if ($check == 0) {
    echo '<div class="alert alert-danger">';
    echo '<p class="lead">هذا الخبر غير موجود لدينا لذلك سيتم توجيهك الى الصفحة الرئيسية الأن</p>';
    echo '</div>';
    header("refresh:2; url=Welcome.php");
} else {
    $the_news =  SelectWhereID('News', $GLOBALS['News_ID']);
    $hospital = SelectWhereID('Hospital', $GLOBALS['News_ID']);
}
?>
<div class="row d-inline">
    <div class="col-11 m-auto">
        <h2><span class="text-primary">عنوان الخبر : </span><?php echo $the_news[0]['Title']; ?></h2>
        <h4><span class="text-primary">الخبر خاص بالمستشفي :</span><?php echo $hospital[0]['Name']; ?></h4>
        <h5><span class="text-primary">تاريخ الخبر :</span><?php echo $the_news[0]['NewsDate']; ?></h5>
        <hr />
        <h6 class="text-primary">تفاصيل الخبر</h6>
        <p class="lead"><?php echo $the_news[0]['Content']; ?></p>
        <hr />
        <a href="<?php echo $path; ?>Welcome.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-home"></i>
            الصفحة الرئيسية
        </a>
        &#160;&#160;
        <a href="<?php echo $path; ?>News.php" type="button" class="text-white btn btn-primary">
            <i class="fa fa-newspaper-o"></i>
            الأخبار
        </a>
    </div>
</div>