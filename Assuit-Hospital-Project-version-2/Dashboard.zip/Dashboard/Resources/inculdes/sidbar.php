<div class="col-8 col-md-3 d-none d-md-block text-right p-0" style="background-size:100% 100%" id="Sidebar">
    <div class="row m-0 p-0">
        <div class="col-12 m-0 p-0 text-center" dir="rtl" id="SidebarHeader">
            <h2 class="d-inline-block">
                <i class="fa fa-cog" aria-hidden="true"></i>&#160;&#160;
                لوحة التحكم
            </h2>

        </div>
        <div class="col-12 m-0 p-0 text-right" id="SidebarContent">
            <div class="row text-center m-0 p-0">
                <!-- Sidbar item -->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebar6','SliderDrobList6')" dir="rtl">
                    <div class="m-0 p-0 SCI">

                        <i class="fa fa-users" aria-hidden="true"></i>&#160;
                        <h3 class="d-inline-block">المشرفين</h3>
                        &#160;<i id="angleArrowSidebar6" class="fa fa-angle-right" aria-hidden="true"></i>

                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5 text-white" style="display: none;" id="SliderDrobList6">
                    <li>
                        <a href="<?php echo $path; ?>Admins.php"> عرض المشرفين</a>
                    </li>
                </ul>
                <!-- Sidbar item -->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebar1','SliderDrobList1')" dir="rtl">
                    <div class="m-0 p-0 SCI">

                        <i class="fa fa-hospital-o" aria-hidden="true"></i> &#160;
                        <h3 class="d-inline-block">المستشفيات</h3>
                        &#160;<i id="angleArrowSidebar1" class="fa fa-angle-right" aria-hidden="true"></i>

                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5 text-white" style="display: none;" id="SliderDrobList1">
                    <li>
                        <a href="<?php echo $path; ?>Hospitals.php"> عرض المستشفيات</a>
                    </li>
                    <li>
                        <a href="<?php echo $path; ?>Hospitals.php?do=add"> أضافة مستشقي</a>
                    </li>
                </ul>
                <!-- Sidbar item -->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebar2','SliderDrobList2')" dir="rtl">
                    <div class="m-0 p-0 SCI">
                        <i class="fa fa-newspaper-o" aria-hidden="true"></i> &#160;
                        الأخبار
                        &#160;<i id="angleArrowSidebar2" class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5  text-white" style="display: none;" id="SliderDrobList2">
                    <li>
                        <a href="<?php echo $path; ?>News.php">عرض الأخبار</a>
                    </li>
                    <li>
                        <a href="<?php echo $path; ?>News.php?do=add">أضافة خبر</a>
                    </li>
                </ul>
                <!-- Sidbar item -->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebar2','SliderDrobList3')" dir="rtl">
                    <div class="m-0 p-0 SCI">
                        <i class="fa fa-puzzle-piece" aria-hidden="true"></i>&#160;
                        الأقسام
                        &#160;<i id="angleArrowSidebar3" class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5  text-white" style="display: none;" id="SliderDrobList3">
                    <li>
                        <a href="<?php echo $path; ?>departments.php">عرض الأقسام</a>
                    </li>
                    <li>
                        <a href="<?php echo $path; ?>departments.php?do=add">أضافة قسم</a>
                    </li>
                </ul>
                <!-- Sidbar item -->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebar4','SliderDrobList4')" dir="rtl">
                    <div class="m-0 p-0 SCI">
                        <i class="fa fa-heartbeat" aria-hidden="true"></i>&#160;
                        العيادات
                        &#160;<i id="angleArrowSidebar4" class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5  text-white" style="display: none;" id="SliderDrobList4">
                    <li>
                        <a href="<?php echo $path; ?>Clinic.php">عرض العيادات</a>
                    </li>
                    <li>
                        <a href="<?php echo $path; ?>Clinic.php?do=add">أضافة عيادة</a>
                    </li>
                </ul>
                <!--MessageItem-->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebarMes','SliderDrobListMes')" dir="rtl">
                    <div class="m-0 p-0 SCI">
                        <i class="fa fa-comments" aria-hidden="true"></i>&#160;
                        الرسائل
                        &#160;<i id="angleArrowSidebarMes" class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5  text-white" style="display: none;"
                    id="SliderDrobListMes">
                    <li>
                        <a href="<?php echo $path; ?>Messages.php">عرض الرسائل</a>
                    </li>
                </ul>
                <!-- Sidbar item -->
                <div class="col-11 text-right text-white SliderItem"
                    onclick="toggleOptions('angleArrowSidebar5','SliderDrobList5')" dir="rtl">
                    <div class="m-0 p-0 SCI">
                        <i class="fa fa-cog" aria-hidden="true"></i>&#160;
                        الأعدادات
                        &#160;<i id="angleArrowSidebar5" class="fa fa-angle-right" aria-hidden="true"></i>
                    </div>
                </div>
                <ul class="col-12 DrobList text-right pr-md-5  text-white" style="display: none;" id="SliderDrobList5">
                    <li>
                        <a href="#">
                            أعدادات الموقع
                            &#160;<i class="fa fa-wrench" aria-hidden="true"></i>
                        </a>
                    </li>
                    <li>
                        <a target="_blank" href="https://localhost/myPhpWork/Site/index.php">
                            زيارة الموقع
                            &#160;<i class="fa fa-share" aria-hidden="true"></i>
                        </a>
                    </li>
                </ul>
            </div>
        </div>
    </div>
</div>