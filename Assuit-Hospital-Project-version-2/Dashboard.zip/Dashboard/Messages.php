<?php

$pageTitle = "لوحة التحكم-الرسائل";
session_start();
include 'pathes.php';

if (isset($_SESSION['User_Name'])) {
    $messages = getAll('ID,Email,Content', 'Message', 'ID');
} else {
    header("Location:index.php");
    exit();
}

?>
<!--Start Content-->

<!--Documention content....-->
<div class="container-fluid m-0 p-0" id="Dashboard">
    <div class="row m-0 p-0">
        <div class="col-12 col-md-9 m-0 p-0" id="mainContent">
            <div class="row m-0 p-0 text-right" dir="rtl">
                <div class="col-12 mainContentHeader text-right" dir="rtl">
                    <img src="Resources/images/Assuit.png" class="float-right circle" width="70px" height="70px" />
                    <h1 class="d-inline-block">مستشفيات جامعة أسيوط</h1>
                    <button type="button" style="float: left;margin-top: 2%;" class="btn btn-danger">
                        <a style="text-decoration: none;" class="text-white" href="<?php echo $path; ?>logOut.php">تسجيل
                            خروج</a>
                    </button>
                </div>
                <div class="col-12 mainContentCoontent text-right" dir="rtl">

                    <!-- Content Here-->
                    <?php include $inculdes . 'ShowMessages.php'; ?>
                    <!-- Content Here-->
                </div>
                <div class="col-12 mainContentFooter text-center" dir="rtl">
                    Dedign and Created by &#128525;
                    <a href="#">
                        Abstract Developers
                    </a>
                </div>
            </div>
        </div>

        <!--Slider Here -->
        <?php
        include $inculdes . 'sidbar.php';
        ?>
    </div>
</div>
<!-- The End of Documention....-->


<!--End Content-->

<!--import footer-->
<?php
include $inculdes . 'footer.php';
?>