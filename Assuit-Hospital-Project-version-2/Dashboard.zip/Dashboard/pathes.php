<?php


//import connection files

include 'connection.php';

/**This Page is very Importance that has my Pathes that will be very helpfull if you want to change in any thing in the path :) **/

//Pathes

$inculdes  =  'Resources/inculdes/';
$jsFiles   =  'Resources/js/';
$cssFiles  =  'Resources/css/';
$path      =  '/myPhpWork/Dashboard/';



//start to include importance file

#you must import language file after an thing or you will founded errors


//import functions file
include $inculdes . 'functions.php';

//import Header file
include  $inculdes . 'head.php';