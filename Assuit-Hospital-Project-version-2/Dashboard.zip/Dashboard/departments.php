<?php

$pageTitle = "لوحة التحكم-الأقسام  ";
session_start();
include 'pathes.php';

if (isset($_SESSION['User_Name'])) {
    /// $news = getAll('ID,NewsDate,Title', 'News', 'ID');
    $department = getAll('ID,Specialization,Name', 'Department', 'ID');
} else {
    header("Location:index.php");
    exit();
}

?>
<!--Start Content-->

<!--Documention content....-->
<div class="container-fluid m-0 p-0" id="Dashboard">
    <div class="row m-0 p-0">
        <div class="col-12 col-md-9 m-0 p-0" id="mainContent">
            <div class="row m-0 p-0 text-right" dir="rtl">
                <div class="col-12 mainContentHeader text-right" dir="rtl">
                    <img src="Resources/images/Assuit.png" class="float-right circle" width="70px" height="70px" />
                    <h1 class="d-inline-block">مستشفيات جامعة أسيوط</h1>
                    <button type="button" style="float: left;margin-top: 2%;" class="btn btn-danger">
                        <a style="text-decoration: none;" class="text-white" href="<?php echo $path; ?>logOut.php">تسجيل
                            خروج</a>
                    </button>
                </div>
                <div class="col-12 mainContentCoontent text-right" dir="rtl">

                    <!-- Content Here-->
                    <?php
                    if ($_SERVER['QUERY_STRING'] == "") {
                        include $inculdes . 'Showdepartments.php';
                    } else {
                        parse_str($_SERVER['QUERY_STRING'], $QSarr);
                        //print_r($QSarr);
                        if (array_key_exists('do', $QSarr)) {
                            switch ($QSarr['do']) {
                                case 'add':
                                    include $inculdes . 'adddepartments.php';
                                    break;
                                case "edit":
                                    $GLOBALS['department_ID'] = $QSarr['department_ID'];
                                    include $inculdes . 'editdepartments.php';
                                    break;
                                case "Delete":
                                    $GLOBALS['department_ID'] = $QSarr['department_ID'];
                                    include $inculdes . 'DeleteDepartments.php';
                                    break;
                                case "Show":
                                    $GLOBALS['department_ID'] = $QSarr['department_ID'];
                                    include $inculdes . 'DepartmentDetails.php';
                                    break;
                            }
                        } else {
                            echo "<center style='color:red'>Not Found</center>";
                        }
                    }

                    ?>
                    <!-- Content Here-->
                </div>
                <div class="col-12 mainContentFooter text-center" dir="rtl">
                    Designed and created by <a target="_blank" href="/myPhpWork/Site/abstractDevelopers.php"
                        class="text-primary">Abstract
                        Developers</a>
                </div>
            </div>
        </div>

        <!--Slider Here -->
        <?php
        include $inculdes . 'sidbar.php';
        ?>
    </div>
</div>
<!-- The End of Documention....-->




<!--End Content-->

<!--import footer-->
<?php
include $inculdes . 'footer.php';
?>